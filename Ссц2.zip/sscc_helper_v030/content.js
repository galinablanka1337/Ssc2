(() => {
if(window.__ssccHelper030)return; window.__ssccHelper030=true;
const re=/(?<!\d)\d{18}(?!\d)/g, sleep=ms=>new Promise(r=>setTimeout(r,ms));
const extract=()=>[...new Set(((document.body&&document.body.innerText)||"").match(re)||[])];
const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"};
function info(){return {title:document.title,url:location.href,codes:extract().length,
inputs:[...document.querySelectorAll("input")].filter(visible).map(e=>({type:e.type,name:e.name||"",id:e.id||"",placeholder:e.placeholder||""})),
buttons:[...document.querySelectorAll("button,input[type=button],input[type=submit],[role=button]")].filter(visible).map(e=>(e.innerText||e.value||"").trim().slice(0,80))};}
async function scan(){const y=scrollY,found=new Set(extract());let steps=0,last=0,stable=0;
while(steps<100){let before=scrollY;scrollTo(0,before+Math.max(350,innerHeight*.75));await sleep(350);extract().forEach(x=>found.add(x));
let h=document.documentElement.scrollHeight;if(scrollY+innerHeight>=h-4&&h===last)stable++;else stable=0;last=h;steps++;if(stable>=2)break;if(scrollY===before&&stable>=1)break;}
scrollTo(0,y);await sleep(150);return {codes:[...found].slice(0,50),total:found.size,steps,info:info()};}
chrome.runtime.onMessage.addListener((m,s,reply)=>{if(m?.type==="INFO"){reply({ok:true,info:info()});return true;}if(m?.type==="SCAN"){scan().then(result=>reply({ok:true,result})).catch(e=>reply({ok:false,error:String(e)}));return true;}});
})();