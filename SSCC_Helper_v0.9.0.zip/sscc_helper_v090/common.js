// Общие функции: состояние хранится ТОЛЬКО в chrome.storage.local (локально в браузере).
var SSCC_VERSION = "0.9.0";
var SSCC_KEY = "ssccState";
var SSCC_CMD_KEY = "ssccCmd";
var SSCC_RES_KEY = "ssccRes";
var SSCC_PAGE = 50;       // строк на одной странице таблицы Nexus
var SSCC_LIMIT = 500;     // максимум номеров в очереди (несколько страниц таблицы)

function ssccBlank() {
  return { items: [], run: "idle", message: "", history: [], log: [], batches: [], tc: { rows: [], selected: [], jobs: [], active: false } };
}
async function ssccLoad() {
  const o = await chrome.storage.local.get(SSCC_KEY);
  const s = o[SSCC_KEY] || ssccBlank();
  // Миграция старого состояния без архива партий.
  if (!Array.isArray(s.batches)) s.batches = [];
  if (!Array.isArray(s.history)) s.history = [];
  if (!Array.isArray(s.items)) s.items = [];
  if (!Array.isArray(s.log)) s.log = [];
  if (!s.tc || !Array.isArray(s.tc.jobs)) s.tc = { rows: [], selected: [], jobs: [], active: false };
  if (!Array.isArray(s.tc.rows)) s.tc.rows = [];
  if (!Array.isArray(s.tc.selected)) s.tc.selected = [];
  return s;
}
async function ssccMutate(fn) {
  const s = await ssccLoad();
  fn(s);
  await chrome.storage.local.set({ [SSCC_KEY]: s });
  return s;
}
function ssccLog(s, text) {
  s.log.push({ t: Date.now(), text: text });
  if (s.log.length > 200) s.log.splice(0, s.log.length - 200);
}

// Добавляет найденные номера в очередь.
//  • Пока в очереди только «ждущие» номера (приёмка не начиналась) — сбор можно повторять, номера накапливаются.
//  • Партия, где всё уже обработано, при следующем сборе автоматически уходит в архив.
//  • Партия, которую начали обрабатывать и не довели (остались номера или есть «ОШИБКА»), с новой не смешивается.
async function ssccAddCodes(codes, label) {
  const r = { found: codes.length, added: 0, dup: 0, prev: 0, over: 0, blocked: false, archived: false };
  await ssccMutate(s => {
    const hasIncoming = codes.length > 0;
    const queued = s.items.some(i => i.status === "queued");
    const processing = s.items.some(i => i.status === "processing");
    const uncertain = s.items.some(i => i.status === "error");
    const started = s.items.some(i => i.status !== "queued");
    const runBusy = ["running", "pausing", "paused", "collecting"].includes(s.run);

    if (hasIncoming && runBusy && s.run !== "collecting") { r.blocked = true; return; }
    if (hasIncoming && s.items.length && !queued && !processing && !uncertain) {
      const closedAt = Date.now();
      s.batches.push({
        id: closedAt, closedAt, result: "completed", total: s.items.length,
        ok: s.items.filter(i => i.status === "ok").length,
        notfound: s.items.filter(i => i.status === "notfound").length,
        errors: 0, items: s.items.map(i => ({ ...i }))
      });
      if (s.batches.length > 100) s.batches.splice(0, s.batches.length - 100);
      s.items = []; s.run = "idle";
      s.message = "Предыдущая партия сохранена в архиве. Подготовлена новая партия.";
      r.archived = true;
      ssccLog(s, "Предыдущая партия автоматически закрыта и сохранена в архиве");
    } else if (hasIncoming && started && (queued || processing || uncertain)) {
      r.blocked = true; return;
    }
    for (const c of codes) {
      const core = c.sscc.slice(-18);
      if (s.items.some(i => i.sscc.slice(-18) === core)) { r.dup++; continue; }
      if (s.history.includes(core)) { r.prev++; continue; }
      if (s.items.length >= SSCC_LIMIT) { r.over++; continue; }
      s.items.push({ n: s.items.length + 1, sscc: c.sscc, pallet: c.pallet, status: "queued", start: 0, end: 0, msg: "" });
      r.added++;
    }
    ssccLog(s, (label || "Сбор") + ": найдено " + r.found + ", добавлено " + r.added + ", повторов " + r.dup + (r.prev ? ", принято ранее " + r.prev : "") + (r.over ? ", сверх лимита " + r.over : ""));
  });
  return r;
}
