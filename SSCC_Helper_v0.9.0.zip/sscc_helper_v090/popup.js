"use strict";
const $ = id => document.getElementById(id);
$("ver").textContent = "v" + SSCC_VERSION;
const STAT = { queued: "в очереди", processing: "В ОБРАБОТКЕ", ok: "успешно", notfound: "не найден/повтор", error: "ОШИБКА", skipped: "пропущен" };
const CLS = { ok: "ok", notfound: "nf", error: "er", skipped: "sk" };
const fmt = t => t ? new Date(t).toLocaleTimeString("ru-RU") : "";
let tabs = { list: null, rdt: null };

function showMsg(text, isErr) { const m = $("msg"); m.textContent = text; m.className = "msg " + (isErr ? "err" : "info"); }

// ---------- вкладки ----------
async function findTabs() {
  const all = await chrome.tabs.query({});
  const lists = [], rdts = [];
  for (const t of all) {
    let u; try { u = new URL(t.url || ""); } catch (e) { continue; }
    if (!u.hostname.endsWith("x5.ru")) continue;
    if (u.hostname.startsWith("rdt.") && u.pathname.includes("/pages/rdt/")) rdts.push(t);
    else if (u.pathname.includes("/advance-notifications")) lists.push(t);
  }
  tabs = { list: lists[0] || null, rdt: rdts[0] || null };
  return { lists, rdts };
}
async function ensureScript(tabId) {
  try { const r = await chrome.tabs.sendMessage(tabId, { type: "PING" }); if (r && r.ok) return true; } catch (e) {}
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["common.js", "content.js"] });
    await new Promise(r => setTimeout(r, 300));
    const r = await chrome.tabs.sendMessage(tabId, { type: "PING" });
    return !!(r && r.ok);
  } catch (e) { return false; }
}
async function send(tabId, msg) {
  if (!(await ensureScript(tabId))) return { ok: false, error: "Нет связи со страницей. Обновите вкладку Nexus (F5) и повторите." };
  try { return await chrome.tabs.sendMessage(tabId, msg); } catch (e) { return { ok: false, error: "Нет связи со страницей: " + e }; }
}

$("find").onclick = async () => {
  const { lists, rdts } = await findTabs();
  let t = "Список ПУП: " + (lists.length ? "найдена ✔" : "НЕ найдена ✖") + "\nПриёмка ПУП: " + (rdts.length ? "найдена ✔" : "НЕ найдена ✖");
  if (rdts.length > 1) t += "\n⚠ Вкладок приёмки несколько (" + rdts.length + "). Оставьте одну.";
  if (lists.length > 1) t += "\n⚠ Вкладок списка несколько (" + lists.length + ").";
  showMsg(t, !lists.length || !rdts.length || rdts.length > 1);
};

// ---------- ПОЛНАЯ АВТОМАТИЗАЦИЯ: один клик, без вопросов ----------
// Берёт ТС, который сейчас открыт в списке (паллеты внизу), и сама проводит его через форму приёмки:
// форма на вводе номера ТС (1/7) — вводит цифры, выбирает ПУП, принимает все SSCC; форма на вводе SSCC (3/7) — просто принимает.
$("fullauto").onclick = async () => {
  const btn = $("fullauto"); btn.disabled = true;
  try {
    const { lists, rdts } = await findTabs();
    if (lists.length !== 1) return showMsg(lists.length ? "Найдено несколько вкладок списка ПУП. Оставьте одну." : "Не найдена вкладка «Уведомления ПУП».", true);
    if (rdts.length !== 1) return showMsg(rdts.length ? "Найдено несколько вкладок приёмки. Оставьте одну." : "Не найдена вкладка приёмки ПУП.", true);
    const s0 = await ssccLoad();
    if (busy(s0)) return showMsg("Сейчас уже идёт работа. Сначала нажмите СТОП.", true);
    const pr = await send(rdts[0].id, { type: "PROBE" });
    if (!pr || !pr.ok) return showMsg((pr && pr.error) || "Нет связи со вкладкой приёмки. Обновите её (F5).", true);
    if (pr.kind !== "tcentry" && pr.kind !== "ready") return showMsg("Форма приёмки должна стоять на вводе номера ТС («Приемка ПУП - 1/7») или на вводе SSCC («3/7»). Сейчас: " + pr.label + ".", true);
    if (pr.hidden) return showMsg("Вкладка приёмки скрыта или свёрнута. Расположите её в отдельном окне рядом со списком.", true);
    const op = await send(lists[0].id, { type: "GET_OPEN" });
    if (!op || !op.ok) return showMsg((op && op.error) || "Не удалось определить открытый ТС.", true);
    const digits = digitsOf(op.plate);
    if (pr.kind === "tcentry" && !digits) return showMsg("Не удалось определить номер ТС для ПУП " + op.code + " в верхней таблице списка.", true);
    await ssccMutate(x => {
      x.items = []; x.run = "idle"; x.message = "";
      x.tc.jobs = [{ code: op.code, plate: op.plate || "—", digits, status: "queued", msg: "", noEnter: pr.kind === "ready" }];
      ssccLog(x, "Полная автоматизация: ТС " + (op.plate || "—") + " / " + op.code + (pr.kind === "ready" ? " (форма уже на вводе SSCC)" : ""));
    });
    const r = await send(rdts[0].id, { type: "START_TC" });
    if (!r || !r.ok) return showMsg((r && r.error) || "Не удалось запустить.", true);
    showMsg("Запущено для ТС " + (op.plate || "") + " · " + op.code + ". Панель можно закрыть. Не трогайте вкладки списка и приёмки.", false);
  } catch (e) {
    showMsg("Ошибка полной автоматизации: " + e, true);
  } finally { btn.disabled = false; }
};

// ---------- сбор ----------
$("collectall").onclick = async () => {
  const s0 = await ssccLoad();
  if (busy(s0)) return showMsg("Во время приёмки собирать номера нельзя.", true);
  const [act] = await chrome.tabs.query({ active: true, currentWindow: true });
  let u; try { u = new URL(act.url || ""); } catch (e) { u = null; }
  if (!u || u.hostname.startsWith("rdt.") || !u.pathname.includes("/advance-notifications"))
    return showMsg("Сначала откройте вкладку «Уведомления ПУП» и нажмите кнопку снова.", true);
  showMsg("Идёт сбор: таблица прокручивается и перелистывается сама. Не трогайте таблицу (до ~1 мин). Результат появится здесь и в журнале.", false);
  $("collectall").disabled = true;
  const r = await send(act.id, { type: "COLLECT_ALL" });
  $("collectall").disabled = false;
  if (!r || !r.ok) return showMsg(r && r.error || "Не удалось собрать.", true);
  let t = "Найдено в таблице: " + r.found + "\nДобавлено новых: " + r.added + "\nУже в очереди: " + r.dup;
  if (r.prev) t += "\nУже принято ранее (пропущено): " + r.prev;
  if (r.over) t += "\nСверх лимита " + SSCC_LIMIT + " (не добавлено): " + r.over;
  if (r.pages) t += "\nСтраниц таблицы обработано: " + r.pages + (r.expected != null ? " (строк в таблице: " + r.expected + ")" : "");
  if (r.problem) t += "\n⚠ СБОР НЕПОЛНЫЙ: " + r.problem;
  if (!r.found) t += "\nSSCC не найдены. Откройте таблицу с колонкой SSCC.";
  showMsg(t, !r.found || !!r.problem);
};
$("collect").onclick = async () => {
  const s0 = await ssccLoad();
  if (busy(s0)) return showMsg("Во время приёмки собирать номера нельзя.", true);
  const [act] = await chrome.tabs.query({ active: true, currentWindow: true });
  let u; try { u = new URL(act.url || ""); } catch (e) { u = null; }
  if (!u || u.hostname.startsWith("rdt.") || !u.pathname.includes("/advance-notifications"))
    return showMsg("Сначала откройте вкладку «Уведомления ПУП» (список с таблицей) и нажмите кнопку снова.", true);
  const r = await send(act.id, { type: "COLLECT" });
  if (!r || !r.ok) return showMsg(r && r.error || "Не удалось собрать.", true);
  const addedResult = await ssccAddCodes(r.codes, "Сбор видимых номеров");
  if (addedResult.blocked) return showMsg("Предыдущая партия не закрыта: есть необработанные или сомнительные номера. Завершите её либо сбросьте партию перед сбором новой таблицы.", true);
  const { added, dup, prev, over } = addedResult;
  let t = "Найдено видимых: " + r.codes.length + "\nДобавлено новых: " + added + "\nУже в очереди: " + dup;
  if (addedResult.archived) t = "Предыдущая партия сохранена в архиве.\n" + t;
  if (prev) t += "\nУже принято ранее (пропущено): " + prev;
  if (over) t += "\nСверх лимита " + SSCC_LIMIT + " (не добавлено): " + over;
  if (r.mode === "loose") t += "\n⚠ Номера найдены вне распознанной таблицы — проверьте очередь.";
  if (!r.codes.length) t += "\nНа экране нет видимых SSCC. Прокрутите таблицу с номерами.";
  showMsg(t, false);
};

// ---------- Режим по ТС ----------
const digitsOf = plate => { const m = (plate || "").match(/\d+/); return m ? m[0] : ""; };
const JOB_ST = { queued: "в очереди", collecting: "сбор SSCC…", receiving: "приёмка…", done: "готово", skipped: "пропущен", error: "ОШИБКА", incomplete: "не завершён" };
const JOB_CLS = { done: "ok", skipped: "nf", error: "er", incomplete: "er" };

$("tcscan").onclick = async () => {
  const s = await ssccLoad(); if (busy(s)) return showMsg("Сначала остановите текущую работу.", true);
  const { lists } = await findTabs();
  if (lists.length !== 1) return showMsg(lists.length ? "Найдено несколько вкладок списка ПУП." : "Не найдена вкладка «Уведомления ПУП».", true);
  showMsg("Читаю список ПУП…", false);
  const r = await send(lists[0].id, { type: "SCAN_ROWS" });
  if (!r || !r.ok) return showMsg((r && r.error) || "Не удалось считать список.", true);
  await ssccMutate(x => { x.tc.rows = r.rows; x.tc.selected = x.tc.selected.filter(c => r.rows.some(w => w.code === c)); ssccLog(x, "Считано ПУП из списка: " + r.rows.length); });
  showMsg("Считано ПУП: " + r.rows.length + (r.rows.some(w => !w.plate) ? "\n⚠ У части строк не найден номер ТС — их выбрать нельзя." : "") + "\nОтметьте нужные ТС галочками.", false);
};
$("tclist").addEventListener("change", async e => {
  const cb = e.target.closest("input[type=checkbox]"); if (!cb) return;
  await ssccMutate(x => { const c = cb.dataset.code; x.tc.selected = x.tc.selected.filter(v => v !== c); if (cb.checked) x.tc.selected.push(c); });
});
$("tcall").onclick = async e => { e.preventDefault(); await ssccMutate(x => { x.tc.selected = x.tc.rows.filter(w => w.plate && !x.tc.jobs.some(j => j.code === w.code && ["done", "receiving", "collecting"].includes(j.status))).map(w => w.code); }); };
$("tcnone").onclick = async e => { e.preventDefault(); await ssccMutate(x => { x.tc.selected = []; }); };

$("tcstart").onclick = async () => {
  const btn = $("tcstart"); btn.disabled = true;
  try {
    const s = await ssccLoad();
    if (busy(s)) return showMsg("Сейчас уже идёт работа. Сначала нажмите СТОП.", true);
    if (s.tc.jobs.some(j => j.status === "queued" || j.status === "receiving")) return showMsg("Есть незавершённые ТС. Нажмите «Продолжить» или «Сбросить партию».", true);
    if (s.items.some(i => i.status === "processing" || i.status === "error")) return showMsg("Есть номер с неизвестным результатом. Проверьте его вручную и нажмите «Сбросить партию».", true);
    const chosen = s.tc.rows.filter(w => s.tc.selected.includes(w.code) && w.plate && digitsOf(w.plate));
    if (!chosen.length) return showMsg("Не выбрано ни одного ТС. Нажмите «Считать ПУП из списка» и отметьте нужные.", true);
    const { lists, rdts } = await findTabs();
    if (lists.length !== 1) return showMsg(lists.length ? "Найдено несколько вкладок списка ПУП." : "Не найдена вкладка «Уведомления ПУП».", true);
    if (rdts.length !== 1) return showMsg(rdts.length ? "Найдено несколько вкладок приёмки." : "Не найдена вкладка приёмки ПУП.", true);
    const p = await send(rdts[0].id, { type: "PROBE" });
    if (!p || !p.ok) return showMsg((p && p.error) || "Нет связи со вкладкой приёмки. Обновите её (F5).", true);
    if (p.kind !== "tcentry") return showMsg("Форма приёмки должна стоять на вводе номера ТС («Приемка ПУП - 1/7»). Сейчас: " + p.label + ".", true);
    if (p.hidden) return showMsg("Вкладка приёмки скрыта или свёрнута. Расположите её в отдельном окне рядом со списком.", true);
    const list = chosen.map(w => "• " + w.plate + " → «" + digitsOf(w.plate) + "»  " + w.code).join("\n");
    if (!confirm("Принять по очереди " + chosen.length + " ТС:\n" + list + "\n\nДля каждого: сбор SSCC, ввод цифр ТС, выбор нужного ПУП, приём всех SSCC.\nПри любой неожиданности программа остановится.\n\nЗапустить?")) return;
    await ssccMutate(x => {
      x.items = []; x.run = "idle"; x.message = "";
      x.tc.jobs = chosen.map(w => ({ code: w.code, plate: w.plate, digits: digitsOf(w.plate), status: "queued", msg: "" }));
      ssccLog(x, "Режим по ТС: выбрано " + chosen.length);
    });
    const r = await send(rdts[0].id, { type: "START_TC" });
    if (!r || !r.ok) return showMsg((r && r.error) || "Не удалось запустить.", true);
    showMsg("Запущено. Панель можно закрыть — работа идёт на страницах. Не трогайте вкладки списка и приёмки.", false);
  } catch (e) { showMsg("Ошибка режима по ТС: " + e, true); } finally { btn.disabled = false; }
};

// ---------- приёмка ----------
async function rdtTab() {
  const { rdts } = await findTabs();
  if (!rdts.length) { showMsg("Не найдена вкладка приёмки ПУП (…/pages/rdt/…).", true); return null; }
  if (rdts.length > 1) { showMsg("Открыто несколько вкладок приёмки. Оставьте одну — иначе возможны повторы.", true); return null; }
  return rdts[0];
}
async function startFlow(type) {
  const s = await ssccLoad();
  if (s.tc.jobs.some(j => j.status === "queued" || j.status === "receiving")) return showMsg("Есть незавершённые ТС (режим по ТС). Нажмите «Продолжить» или «Сбросить партию».", true);
  const q = s.items.filter(i => i.status === "queued").length;
  if (!q) return showMsg("В очереди нет номеров для приёмки.", true);
  if (s.items.some(i => i.status === "processing")) return showMsg("Есть номер «в обработке» с неизвестным результатом. Проверьте его вручную; при обновлении страницы приёмки он станет «ОШИБКА».", true);
  const t = await rdtTab(); if (!t) return;
  const text = type === "TEST1" ? "Принять ТОЛЬКО ОДИН номер для проверки?" : "Принять " + q + " номеров по очереди?\nФорма приёмки должна быть на экране ввода SSCC.";
  if (!confirm(text)) return;
  const r = await send(t.id, { type });
  if (!r || !r.ok) showMsg(r && r.error || "Не удалось запустить.", true);
}
$("start").onclick = () => startFlow("START");
$("test1").onclick = () => startFlow("TEST1");
$("resume").onclick = async () => {
  const t = await rdtTab(); if (!t) return; const s = await ssccLoad();
  const tcPending = s.tc.jobs.some(j => j.status === "queued" || j.status === "receiving");
  if (s.run === "paused") { const r = await send(t.id, { type: tcPending ? "START_TC" : "START" }); if (!r.ok) showMsg(r.error, true); }
  else if (tcPending) { if (!confirm("Продолжить обработку незавершённых ТС?")) return; const r = await send(t.id, { type: "START_TC" }); if (!r || !r.ok) showMsg((r && r.error) || "Не удалось продолжить.", true); }
  else startFlow("START");
};
$("pause").onclick = async () => { const t = await rdtTab(); if (!t) return; const r = await send(t.id, { type: "PAUSE" }); if (!r.ok) showMsg(r.error, true); };
$("stop").onclick = async () => {
  const { lists, rdts } = await findTabs();
  if (lists[0]) { try { await send(lists[0].id, { type: "CANCEL" }); } catch (e) {} }
  if (rdts.length !== 1) { await ssccMutate(s => { s.run = "stopped"; s.message = "Остановлено пользователем"; }); return; }
  const r = await send(rdts[0].id, { type: "STOP" }); if (!r.ok) showMsg(r.error, true);
};

// ---------- очистка ----------
function busy(s) { return ["running", "pausing", "paused", "collecting"].includes(s.run); }
$("clearq").onclick = async () => {
  const s = await ssccLoad(); if (busy(s)) return showMsg("Сначала остановите приёмку.", true);
  if (!confirm("Убрать из очереди все необработанные номера?")) return;
  await ssccMutate(x => { x.items = x.items.filter(i => i.status !== "queued"); x.items.forEach((i, k) => i.n = k + 1); ssccLog(x, "Очередь очищена"); });
};
$("reset").onclick = async () => {
  const s = await ssccLoad(); if (busy(s)) return showMsg("Сначала остановите приёмку.", true);
  if (!confirm("Сбросить текущую партию (очередь и результаты)? Историю принятых номеров это не затрагивает.")) return;
  await ssccMutate(x => {
    if (x.items.length) {
      const closedAt = Date.now();
      x.batches = Array.isArray(x.batches) ? x.batches : [];
      x.batches.push({ id: closedAt, closedAt, result: "manual_reset", total: x.items.length,
        ok: x.items.filter(i => i.status === "ok").length,
        notfound: x.items.filter(i => i.status === "notfound").length,
        errors: x.items.filter(i => i.status === "error").length,
        items: x.items.map(i => ({ ...i })) });
      if (x.batches.length > 100) x.batches.splice(0, x.batches.length - 100);
    }
    x.items = []; x.run = "idle"; x.message = ""; ssccLog(x, "Партия сброшена и сохранена в архиве");
  });
  showMsg("Партия сброшена. Листайте таблицу и собирайте номера. История успешно принятых SSCC сохранена.", false);
};
$("clearhist").onclick = async e => {
  e.preventDefault();
  if (!confirm("Очистить историю ранее принятых номеров? После этого их можно будет собрать и принять снова.")) return;
  await ssccMutate(x => { x.history = []; ssccLog(x, "История принятых очищена"); });
};

// ---------- отрисовка ----------
function render(s) {
  if (!s.tc || !Array.isArray(s.tc.jobs)) s.tc = { rows: [], selected: [], jobs: [], active: false };
  if (!Array.isArray(s.tc.rows)) s.tc.rows = [];
  if (!Array.isArray(s.tc.selected)) s.tc.selected = [];
  const c = k => s.items.filter(i => i.status === k).length;
  const total = s.items.length, queued = c("queued"), ok = c("ok"), nf = c("notfound"), er = c("error"), sk = c("skipped");
  $("s_total").textContent = total; $("s_queued").textContent = queued; $("s_done").textContent = ok + nf + er + sk;
  $("s_left").textContent = queued; $("s_ok").textContent = ok; $("s_nf").textContent = nf; $("s_er").textContent = er;
  const run = s.run, active = busy(s);
  $("collect").disabled = active; $("collectall").disabled = active; $("fullauto").disabled = active; $("start").disabled = active || !queued; $("test1").disabled = active || !queued;
  $("pause").disabled = run !== "running"; const tcPend = s.tc.jobs.some(j => j.status === "queued" || j.status === "receiving");
  $("resume").disabled = !(run === "paused" || ((run === "stopped" || run === "error") && (queued || tcPend)));
  $("tcscan").disabled = active; $("tcstart").disabled = active;
  $("stop").disabled = !active; $("clearq").disabled = active; $("reset").disabled = active;
  if (run === "error" || run === "done" || run === "stopped" || run === "pausing" || run === "paused" || run === "collecting") showMsg(s.message || run, run === "error");
  else if (run === "running") showMsg("Идёт приёмка… " + (ok + nf + er) + " из " + total, false);
  const cur = s.items.find(i => i.status === "processing") || (run !== "idle" ? s.items.find(i => i.status === "queued") : null);
  const jobOf = c => s.tc.jobs.find(j => j.code === c);
  $("tclist").innerHTML = s.tc.rows.map(w => {
    const j = jobOf(w.code), d = digitsOf(w.plate);
    const info = j ? JOB_ST[j.status] + (j.status === "done" ? " (" + (j.ok || 0) + (j.notfound ? " / не найдено " + j.notfound : "") + ")" : "") + (j.msg ? " — " + j.msg.slice(0, 70) : "") : "";
    return `<div class="${j ? (JOB_CLS[j.status] || "") : ""}"><label><input type="checkbox" data-code="${w.code}" ${s.tc.selected.includes(w.code) ? "checked" : ""} ${active || !w.plate ? "disabled" : ""}> ${w.plate || "ТС?"}${d ? " → " + d : ""} · ${w.code}${info ? "<br>&nbsp;&nbsp;&nbsp;&nbsp;" + info.replace(/</g, "&lt;") : ""}</label></div>`;
  }).join("") + s.tc.jobs.filter(j => !s.tc.rows.some(w => w.code === j.code)).map(j => `<div class="${JOB_CLS[j.status] || ""}">${j.plate} · ${j.code}<br>&nbsp;&nbsp;&nbsp;&nbsp;${JOB_ST[j.status]}${j.msg ? " — " + j.msg.slice(0, 70).replace(/</g, "&lt;") : ""}</div>`).join("") || '<div class="sk">Нажмите «Считать ПУП из списка»</div>';
  $("list").innerHTML = s.items.map(i => `<div class="${i === cur ? "cur " : ""}${CLS[i.status] || ""}">${i.n}. ${i.sscc} — ${STAT[i.status]}${i.msg ? " (" + i.msg.slice(0, 60) + ")" : ""}</div>`).join("") || '<div class="sk">пусто</div>';
  $("log").innerHTML = s.log.slice(-40).reverse().map(l => `<div>${fmt(l.t)} ${l.text.replace(/</g, "&lt;")}</div>`).join("");
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch[SSCC_KEY]) render(ch[SSCC_KEY].newValue || ssccBlank()); });
ssccLoad().then(s => { render(s); if (["error", "done", "stopped"].includes(s.run) === false) findTabs(); });
