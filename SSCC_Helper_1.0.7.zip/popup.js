"use strict";
const $ = id => document.getElementById(id);
$("ver").textContent = "v" + SSCC_VERSION;
const fmt = t => t ? new Date(t).toLocaleTimeString("ru-RU") : "";
let tabs = { list: null, rdt: null };
const HINT = "Откройте список ПУП и форму приёмки («Приемка ПУП - 1/7») в двух окнах рядом и нажмите кнопку.";

function showMsg(text, isErr) { const m = $("msg"); m.textContent = text; m.className = "msg " + (isErr ? "err" : "info"); }
function busy(s) { return ["running", "pausing", "paused", "collecting"].includes(s.run); }

// ---------- вкладки ----------
async function findTabs() {
  const all = await chrome.tabs.query({});
  const lists = [], rdts = [];
  for (const t of all) {
    let u; try { u = new URL(t.url || ""); } catch (e) { continue; }
    if (!u.hostname.endsWith("x5.ru")) continue;
    if (u.hostname.startsWith("rdt.") && u.pathname.includes("/pages/rdt/")) rdts.push(t);
    else if (u.pathname.includes("/advance-notifications")) lists.push(t);
  }
  tabs = { list: lists[0] || null, rdt: rdts[0] || null };
  return { lists, rdts };
}
async function ensureScript(tabId) {
  try { const r = await chrome.tabs.sendMessage(tabId, { type: "PING" }); if (r && r.ok) return true; } catch (e) {}
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["common.js", "content.js"] });
    await new Promise(r => setTimeout(r, 300));
    const r = await chrome.tabs.sendMessage(tabId, { type: "PING" });
    return !!(r && r.ok);
  } catch (e) { return false; }
}
async function send(tabId, msg) {
  if (!(await ensureScript(tabId))) return { ok: false, error: "Нет связи со страницей. Обновите вкладку Nexus (F5) и повторите." };
  try { return await chrome.tabs.sendMessage(tabId, msg); } catch (e) { return { ok: false, error: "Нет связи со страницей: " + e }; }
}

const digitsOf = plate => { const m = (plate || "").match(/\d+/); return m ? m[0] : ""; };
const JOB_ST = { queued: "в очереди", collecting: "сбор SSCC…", receiving: "приёмка…", done: "готово", skipped: "пропущен", error: "ОШИБКА", incomplete: "не завершён" };
const JOB_CLS = { done: "ok", skipped: "nf", error: "er", incomplete: "er" };

// ---------- ПОЛНАЯ АВТОМАТИЗАЦИЯ: одна кнопка ----------
async function startFull() {
  const btn = $("main"); btn.disabled = true;
  try {
    const { lists, rdts } = await findTabs();
    if (lists.length !== 1) return showMsg(lists.length ? "Найдено несколько вкладок списка ПУП. Оставьте одну." : "Не найдена вкладка «Уведомления ПУП».", true);
    if (rdts.length !== 1) return showMsg(rdts.length ? "Найдено несколько вкладок приёмки. Оставьте одну." : "Не найдена вкладка приёмки ПУП.", true);
    const s0 = await ssccLoad();
    if (busy(s0)) return showMsg("Сейчас уже идёт работа. Сначала нажмите СТОП.", true);
    const pr = await send(rdts[0].id, { type: "PROBE" });
    if (!pr || !pr.ok) return showMsg((pr && pr.error) || "Нет связи со вкладкой приёмки. Обновите её (F5).", true);
    if (pr.kind !== "tcentry") return showMsg("Форма приёмки должна стоять на вводе номера ТС («Приемка ПУП - 1/7»). Сейчас: " + pr.label + ".", true);
    if (pr.hidden) return showMsg("Вкладка приёмки скрыта или свёрнута. Расположите её в отдельном окне рядом со списком.", true);
    const r = await send(lists[0].id, { type: "FULL_AUTO_ALL" });
    if (!r || !r.ok) return showMsg((r && r.error) || "Не удалось запустить.", true);
    showMsg("Запущено. Программа сама пройдёт все ТС из списка со статусом «Не подтверждено». Панель можно закрыть. Не трогайте вкладки списка и приёмки.", false);
  } catch (e) {
    showMsg("Ошибка полной автоматизации: " + e, true);
  } finally { btn.disabled = false; }
}

async function stopAll() {
  const { lists, rdts } = await findTabs();
  if (lists[0]) { try { await send(lists[0].id, { type: "CANCEL" }); } catch (e) {} }
  if (rdts.length !== 1) { await ssccMutate(s => { s.run = "stopped"; s.message = "Остановлено пользователем"; }); return; }
  const r = await send(rdts[0].id, { type: "STOP" }); if (!r.ok) showMsg(r.error, true);
}
$("main").onclick = async () => { const s = await ssccLoad(); return busy(s) ? stopAll() : startFull(); };

// «Продолжить» и «Сбросить» появляются только после остановки/ошибки, когда остались незавершённые ТС
$("resume").onclick = async () => {
  const { rdts } = await findTabs();
  if (rdts.length !== 1) return showMsg(rdts.length ? "Найдено несколько вкладок приёмки. Оставьте одну." : "Не найдена вкладка приёмки ПУП.", true);
  const r = await send(rdts[0].id, { type: "START_TC" });
  if (!r || !r.ok) showMsg((r && r.error) || "Не удалось продолжить.", true);
};
$("reset").onclick = async () => {
  const s = await ssccLoad(); if (busy(s)) return showMsg("Сначала нажмите СТОП.", true);
  if (!confirm("Сбросить текущую партию (очередь и список ТС)? Историю принятых номеров это не затрагивает.")) return;
  await ssccMutate(x => {
    if (x.items.length) {
      const closedAt = Date.now();
      x.batches = Array.isArray(x.batches) ? x.batches : [];
      x.batches.push({ id: closedAt, closedAt, result: "manual_reset", total: x.items.length,
        ok: x.items.filter(i => i.status === "ok").length,
        notfound: x.items.filter(i => i.status === "notfound").length,
        errors: x.items.filter(i => i.status === "error").length,
        items: x.items.map(i => ({ ...i })) });
      if (x.batches.length > 100) x.batches.splice(0, x.batches.length - 100);
    }
    x.items = []; x.run = "idle"; x.message = ""; x.tc = { rows: [], selected: [], jobs: [], active: false };
    ssccLog(x, "Партия сброшена и сохранена в архиве");
  });
  showMsg(HINT, false);
};

// ---------- отрисовка ----------
function render(s) {
  if (!s.tc || !Array.isArray(s.tc.jobs)) s.tc = { rows: [], selected: [], jobs: [], active: false };
  const c = k => s.items.filter(i => i.status === k).length;
  const run = s.run, active = busy(s), jobs = s.tc.jobs;
  const live = jobs.some(j => j.status === "receiving");          // текущий ТС ещё принимается: добавляем его живые счётчики
  const sum = f => jobs.reduce((a, j) => a + (j.status === "done" ? (j[f] || 0) : 0), 0);
  const okN = sum("ok") + (live ? c("ok") : 0), nfN = sum("notfound") + (live ? c("notfound") : 0), erN = sum("errors") + (live ? c("error") : 0);
  const finished = jobs.filter(j => !["queued", "collecting", "receiving"].includes(j.status)).length;
  $("s_tc").textContent = jobs.length ? finished + " из " + jobs.length : "—";
  $("s_ok").textContent = okN; $("s_er").textContent = erN + " / " + nfN;

  const main = $("main");
  main.textContent = active ? "■  СТОП" : "▶  ПОЛНАЯ АВТОМАТИЗАЦИЯ";
  main.className = "fullauto" + (active ? " stopmode" : "");
  const tcPend = jobs.some(j => j.status === "queued" || j.status === "receiving");
  $("extra").style.display = (!active && (run === "error" || run === "stopped") && tcPend) ? "flex" : "none";

  if (run === "error" || run === "done" || run === "stopped" || run === "pausing" || run === "paused" || run === "collecting") showMsg(s.message || run, run === "error");
  else if (run === "running") showMsg("Идёт приёмка… " + (okN + nfN + erN) + " SSCC обработано", false);

  $("tclist").style.display = jobs.length ? "block" : "none";
  $("tclist").innerHTML = jobs.map(j => {
    const d = digitsOf(j.plate);
    const info = JOB_ST[j.status] + (j.status === "done" ? " (" + (j.ok || 0) + (j.notfound ? " / не найдено " + j.notfound : "") + ")" : "") + (j.msg ? " — " + j.msg.slice(0, 70) : "");
    return `<div class="${JOB_CLS[j.status] || ""}">${(j.plate || "ТС?")}${d ? " → " + d : ""} · ${j.code}<br>&nbsp;&nbsp;${info.replace(/</g, "&lt;")}</div>`;
  }).join("");
  $("log").innerHTML = s.log.slice(-40).reverse().map(l => `<div>${fmt(l.t)} ${l.text.replace(/</g, "&lt;")}</div>`).join("");
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch[SSCC_KEY]) render(ch[SSCC_KEY].newValue || ssccBlank()); });
ssccLoad().then(s => { render(s); if (!s.message && s.run === "idle") showMsg(HINT, false); });
