(() => {
"use strict";
if (!chrome.runtime || !chrome.runtime.id) return;

// ---------- Настройки (тайм-ауты и известные ошибки) ----------
const T_READY = 10000;     // ждать готовую форму
const T_RESULT = 20000;    // ждать ответ после «Отправить»
const T_BACK = 15000;      // ждать возврат формы после «Нет» / «Ок»
// Ошибки, которые считаем «SSCC не найден / повторный». Всё остальное = неизвестная ошибка → СТОП.
const KNOWN_NOTFOUND = [/не\s+найден/i, /уже\s+(принят|зарегистр|отсканир|подтвержд)/i, /повторн/i, /дублир/i];

const sleep = ms => new Promise(r => setTimeout(r, ms));
const norm = s => (s || "").replace(/\s+/g, " ").trim();
const isRdt = () => location.hostname.startsWith("rdt.") && location.pathname.includes("/pages/rdt/");
const isList = () => !location.hostname.startsWith("rdt.") && location.pathname.includes("/advance-notifications");

const vis = e => {
  if (!e || !e.isConnected) return false;
  const r = e.getBoundingClientRect(), s = getComputedStyle(e);
  return r.width > 0 && r.height > 0 && s.display !== "none" && s.visibility !== "hidden";
};

async function waitFor(fn, timeout, step = 150) {
  const t0 = Date.now();
  for (;;) {
    const v = fn();
    if (v) return v;
    if (Date.now() - t0 > timeout) return null;
    await sleep(step);
  }
}

// =====================================================================
//  СТРАНИЦА СПИСКА ПУП: сбор SSCC (с авто-прокруткой и перелистыванием страниц таблицы)
// =====================================================================
const SSCC_RE = /^(?:\d{18}|\d{20})$/;
const RANGE_RE = /^(\d+)\s*[–—-]\s*(\d+)\s+из\s+(\d+)$/;   // «1–50 из 51»
const MAX_PAGES = 20;
let cancelCollect = false;
const CANCELLED = "collect-cancelled";
const checkCancel = () => { if (cancelCollect) throw new Error(CANCELLED); };

// Элемент реально отрисован (есть размер, не скрыт).
function rendered(el) {
  if (!el || !el.isConnected) return false;
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== "hidden";
}

// Элемент виден на экране: центр внутри окна и внутри всех «обрезающих» родителей.
// Плавающие значки поверх таблицы (например, круглый X5) НЕ учитываются — они не мешают.
function insideViewAndClips(el) {
  if (!rendered(el)) return false;
  const r = el.getBoundingClientRect();
  const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  if (cx < 0 || cy < 0 || cx > innerWidth || cy > innerHeight) return false;
  for (let p = el.parentElement; p && p !== document.documentElement; p = p.parentElement) {
    const ps = getComputedStyle(p);
    if (/(auto|scroll|hidden|clip)/.test(ps.overflow + ps.overflowX + ps.overflowY)) {
      const pr = p.getBoundingClientRect();
      if (cx < pr.left || cx > pr.right || cy < pr.top || cy > pr.bottom) return false;
    }
  }
  return true;
}

// mode "view" — только видимое на экране (ручной сбор); mode "dom" — всё отрисованное в таблице (авто-сбор).
function collectVisible(mode) {
  const geo = mode === "dom" ? rendered : insideViewAndClips;
  const STRICT = '[role="row"],[role="gridcell"],[role="cell"],tr,td,[class*="row" i],[class*="cell" i],[class*="grid" i],[class*="table" i]';
  const strict = [], loose = [];
  const seenS = new Set(), seenL = new Set();
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = w.nextNode())) {
    const t = n.nodeValue.trim();
    if (!SSCC_RE.test(t)) continue;
    const el = n.parentElement;
    if (!el || /^(SCRIPT|STYLE|INPUT|TEXTAREA)$/.test(el.tagName)) continue;
    if (!geo(el)) continue;
    const row = el.closest('[role="row"],tr,[class*="row" i]');
    const rowTxt = row && row.innerText.length < 400 ? row.innerText : "";   // только если это одна строка, а не вся таблица
    const m = rowTxt.match(/\bD\d{6,}\b/);
    const confirmed = /подтвержд/i.test(rowTxt) && !/не\s*подтвержд/i.test(rowTxt);
    const rec = { sscc: t, pallet: m ? m[0] : "", confirmed };
    if (!seenL.has(t)) { seenL.add(t); loose.push(rec); }
    if (el.closest(STRICT) && !seenS.has(t)) { seenS.add(t); strict.push(rec); }
  }
  return strict.length ? { codes: strict, mode: "table" } : { codes: loose, mode: "loose" };
}

// Первая отрисованная ячейка с SSCC — «якорь» таблицы.
function ssccAnchor() {
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = w.nextNode())) {
    if (!SSCC_RE.test(n.nodeValue.trim())) continue;
    const el = n.parentElement;
    if (el && !/^(SCRIPT|STYLE|INPUT|TEXTAREA)$/.test(el.tagName) && rendered(el)) return el;
  }
  return null;
}
// Цепочка прокручиваемых контейнеров вокруг якоря (от внутреннего к внешнему).
function scrollerChain(anchor) {
  const out = [];
  for (let p = anchor.parentElement; p && p !== document.documentElement; p = p.parentElement) {
    if (/(auto|scroll|overlay)/.test(getComputedStyle(p).overflowY) && p.scrollHeight > p.clientHeight + 2) out.push(p);
  }
  const de = document.scrollingElement;
  if (de && de.scrollHeight > de.clientHeight + 2) out.push(de);
  return out;
}

// Читает подпись «1–50 из 51» под таблицей с SSCC.
function readRange(ref) {
  const rr = ref.getBoundingClientRect();
  let best = null, bestD = 1e9;
  for (const e of document.querySelectorAll("div,span,p,td,li,label")) {
    const t = norm(e.textContent);
    if (t.length > 30) continue;
    const m = RANGE_RE.exec(t);
    if (!m || !rendered(e)) continue;
    if ([...e.children].some(c => RANGE_RE.test(norm(c.textContent)))) continue;
    const r = e.getBoundingClientRect();
    const d = r.top - rr.bottom;
    if (d < -60 || r.left > rr.right || r.right < rr.left) continue;
    if (Math.abs(d) < bestD) { bestD = Math.abs(d); best = { el: e, start: +m[1], end: +m[2], total: +m[3] }; }
  }
  return best;
}
function readRangeAuto() {
  const a = ssccAnchor(); if (!a) return null;
  const ch = scrollerChain(a);
  return readRange(ch[0] || a);
}

function realClick(el) {
  const o = { bubbles: true, cancelable: true, view: window };
  for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"])
    el.dispatchEvent(new (t.startsWith("pointer") ? PointerEvent : MouseEvent)(t, o));
}

// Переход на следующую страницу таблицы: сначала кнопка с номером страницы, потом стрелка «›».
async function goNextPage(rng) {
  const size = Math.max(1, rng.end - rng.start + 1);
  const want = String(Math.floor((rng.start - 1) / size) + 2);
  const rr = rng.el.getBoundingClientRect(), cy = rr.top + rr.height / 2;
  const band = e => { const r = e.getBoundingClientRect(); return rendered(e) && Math.abs(r.top + r.height / 2 - cy) < 30 && r.left >= rr.left; };
  const all = [...document.querySelectorAll("button,[role=button],a,li,div,span")].filter(band);
  const tryClick = async el => {
    realClick(el);
    return !!(await waitFor(() => { const r = readRangeAuto(); return r && r.start === rng.end + 1 ? r : null; }, 10000));
  };
  // 1) кнопка с номером следующей страницы
  const nums = all.filter(e => norm(e.textContent) === want && ![...e.children].some(c => norm(c.textContent) === want))
    .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
  if (nums.length && await tryClick(nums[0])) return true;
  // 2) стрелка «следующая»
  const arrows = all.filter(e => /^(button|a|li)$/i.test(e.tagName) || e.getAttribute("role") === "button")
    .filter(e => !e.disabled && e.getAttribute("aria-disabled") !== "true" && !/disabled/i.test(e.className || ""))
    .filter(e => { const t = (norm(e.textContent) + " " + (e.getAttribute("aria-label") || "") + " " + (e.title || "") + " " + (e.className || "")); return /next|след|›|»|>/i.test(t); });
  if (arrows.length && await tryClick(arrows[arrows.length - 1])) return true;
  return false;
}

// Прокручивает один контейнер сверху вниз до самого конца, собирая строки на каждом шаге.
async function scrollThrough(sc, ctx) {
  sc.scrollTop = 0; await sleep(500);
  let bottomTicks = 0, stuck = 0;
  for (let i = 0; i < 250; i++) {
    checkCancel(); ctx.grab();
    if (ctx.done()) break;
    const maxTop = sc.scrollHeight - sc.clientHeight, before = sc.scrollTop;
    if (before >= maxTop - 2) {            // дошли до низа: даём строкам догрузиться
      await sleep(500); ctx.grab();
      if (ctx.done() || ++bottomTicks >= 3) break;
      continue;
    }
    sc.scrollTop = Math.min(maxTop, before + Math.max(40, Math.floor(sc.clientHeight * 0.5)));
    await sleep(300);
    if (sc.scrollTop === before) {         // не сдвинулось — подтолкнём колесом
      sc.dispatchEvent(new WheelEvent("wheel", { deltaY: Math.max(60, Math.floor(sc.clientHeight * 0.5)), bubbles: true, cancelable: true }));
      await sleep(300);
      if (sc.scrollTop === before && ++stuck >= 3) break;
    }
  }
  ctx.grab();
  sc.scrollTop = 0;
}

// Собирает ВСЕ строки текущей страницы таблицы.
async function collectPage(acc) {
  const anchor = await waitFor(() => ssccAnchor(), 8000);
  if (!anchor) return { got: 0, expected: null };
  const pageSet = new Set();
  const rng0 = readRange((scrollerChain(anchor)[0]) || anchor);
  const expected = rng0 ? rng0.end - rng0.start + 1 : null;
  const ctx = {
    grab() { for (const c of collectVisible("dom").codes) { pageSet.add(c.sscc); if (!acc.has(c.sscc)) acc.set(c.sscc, c); } },
    done() { return expected != null && pageSet.size >= expected; }
  };
  const chain = scrollerChain(anchor);
  if (!chain.length) { await sleep(400); ctx.grab(); }
  for (const sc of chain) {                 // сначала внутренний контейнер, при нехватке — внешние
    await scrollThrough(sc, ctx);
    if (ctx.done()) break;
  }
  ctx.grab();
  return { got: pageSet.size, expected };
}

// Полный сбор: все строки страницы → следующая страница → … пока она есть.
async function collectGrid(progress) {
  cancelCollect = false;
  const acc = new Map();
  const res = { codes: [], pages: 0, expected: null, problem: "" };
  const seen = new Set();
  for (;;) {
    checkCancel();
    if (progress) await progress("Страница " + (res.pages + 1) + ": прокручиваю таблицу до конца… собрано " + acc.size);
    const pg = await collectPage(acc);
    res.pages++;
    const rng = readRangeAuto();
    if (rng) res.expected = rng.total;
    if (pg.expected != null && pg.got < pg.expected) { res.problem = "На странице " + res.pages + " собрано " + pg.got + " из " + pg.expected + " строк."; break; }
    if (!rng || rng.end >= rng.total) break;            // следующей страницы нет
    if (seen.has(rng.start) || res.pages >= MAX_PAGES) { res.problem = "Не удалось пролистать таблицу дальше (страница " + res.pages + ")."; break; }
    seen.add(rng.start);
    if (progress) await progress("Перехожу на страницу " + (res.pages + 1) + "… собрано " + acc.size);
    if (!(await goNextPage(rng))) { res.problem = "Есть следующая страница (всего строк " + rng.total + "), но перейти на неё не удалось."; break; }
    await sleep(600);
  }
  res.codes = [...acc.values()];
  if (!res.problem && res.expected != null && res.codes.length !== res.expected)
    res.problem = "Собрано " + res.codes.length + " из " + res.expected + " строк таблицы.";
  return res;
}

// ---------- Режим по ТС: работа со списком ПУП (верхняя таблица + превью паллетов) ----------
const PUP_RE = /^\d{3,7}_\d+_\d+$/;
const PLATE_RE = /^[A-ZА-ЯЁ]\d{3}[A-ZА-ЯЁ]{2}\d{2,3}$/i;

function pupCodeEls(code) {
  const out = [];
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = w.nextNode())) {
    const t = n.nodeValue.trim();
    if (!PUP_RE.test(t) || (code && t !== code)) continue;
    const el = n.parentElement;
    if (el && rendered(el)) out.push(el);
  }
  return out;
}
function rowOf(el) { return el.closest('[role="row"],tr,[class*="row" i]') || el.parentElement.parentElement; }

function previewOpenFor(code) {
  for (const e of document.querySelectorAll("div,span,p,h1,h2,h3,b,strong")) {
    const t = norm(e.textContent);
    if (t.length < 90 && t.startsWith("Паллеты в составе") && (!code || t.includes(code)) && rendered(e)) return true;
  }
  return false;
}
// Закрывает нижнюю панель с паллетами (крестик справа от «Добавить паллету»), чтобы верхняя таблица снова показала все ПУП.
async function closePreview() {
  if (!previewOpenFor()) return;
  const add = findButton(/^\+?\s*Добавить паллету$/i);
  if (!add) return;
  const ar = add.getBoundingClientRect(), cy = ar.top + ar.height / 2;
  const cands = [...document.querySelectorAll("button,[role=button],svg,i,span,div")].filter(e => {
    const r = e.getBoundingClientRect();
    return rendered(e) && r.width >= 8 && r.width <= 44 && r.height >= 8 && r.height <= 44 && r.left >= ar.right && r.left < ar.right + 260 && Math.abs(r.top + r.height / 2 - cy) < 20;
  }).sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);
  for (const c of cands.slice(0, 2)) {
    realClick(c);
    if (await waitFor(() => !previewOpenFor(), 3000)) { await sleep(500); return; }
  }
}
// Значок «Показать окошко превью» (квадрат с чертой) сразу справа от кода ПУП.
function previewIconCandidates(codeEl) {
  const cr = codeEl.getBoundingClientRect(), row = rowOf(codeEl);
  return [...row.querySelectorAll("*")].filter(e => {
    if (e === codeEl || codeEl.contains(e) || e.contains(codeEl)) return false;
    const r = e.getBoundingClientRect();
    return rendered(e) && r.width >= 8 && r.width <= 48 && r.height >= 8 && r.height <= 48 &&
      r.left >= cr.right - 4 && r.left < cr.right + 180 && Math.abs(r.top + r.height / 2 - (cr.top + cr.height / 2)) < 22;
  }).sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
}
async function findPupCodeEl(code) {
  let el = pupCodeEls(code)[0];
  if (el) return el;
  const any = pupCodeEls()[0];
  if (!any) return null;
  for (const sc of scrollerChain(any)) {            // строка может быть ниже — листаем верхнюю таблицу
    sc.scrollTop = 0; await sleep(300);
    for (let i = 0; i < 120; i++) {
      checkCancel();
      el = pupCodeEls(code)[0]; if (el) return el;
      const maxTop = sc.scrollHeight - sc.clientHeight;
      if (sc.scrollTop >= maxTop - 2) break;
      sc.scrollTop = Math.min(maxTop, sc.scrollTop + Math.max(30, Math.floor(sc.clientHeight * 0.5)));
      await sleep(250);
    }
  }
  return null;
}
async function openPreview(code) {
  if (previewOpenFor(code)) { await sleep(300); return { ok: true };   // уже открыт — ничего не нажимаем
  }
  await closePreview();
  const el = await findPupCodeEl(code);
  if (!el) return { ok: false, error: "ПУП " + code + " не найден в верхней таблице списка." };
  el.scrollIntoView({ block: "center", inline: "nearest" });
  await sleep(300);
  const cands = previewIconCandidates(el);
  if (!cands.length) return { ok: false, error: "Не найден значок превью справа от кода " + code + "." };
  for (const c of cands.slice(0, 3)) {
    realClick(c);
    if (await waitFor(() => previewOpenFor(code), 6000)) { await sleep(600); return { ok: true }; }
  }
  return { ok: false, error: "Панель «Паллеты в составе " + code + "» не открылась после нажатия значка." };
}
function rowInfo(el) {
  const code = norm(el.textContent), row = rowOf(el), txt = row ? norm(row.innerText) : "";
  const pm = /[A-ZА-ЯЁ]\d{3}[A-ZА-ЯЁ]{2}\d{2,3}/i.exec(txt.split(code).join(" "));
  const st = /Не\s*подтвержден\S*|Подтвержден\S*/i.exec(txt);
  return { code, plate: pm ? pm[0] : "", status: st ? st[0] : "" };
}
// Какой ПУП сейчас открыт внизу («Паллеты в составе …») и какой у него номер ТС.
async function getOpenPup() {
  let code = "";
  for (const e of document.querySelectorAll("div,span,p,h1,h2,h3,b,strong")) {
    const t = norm(e.textContent);
    const m = t.length < 90 && /^Паллеты в составе\s+(\S+)$/.exec(t);
    if (m && rendered(e) && PUP_RE.test(m[1])) { code = m[1]; break; }
  }
  if (!code) return { ok: false, error: "В списке не открыт ТС: нажмите значок рядом с кодом ПУП, чтобы внизу показались паллеты." };
  const el = await findPupCodeEl(code);
  const info = el ? rowInfo(el) : { code, plate: "", status: "" };
  return { ok: true, code, plate: info.plate };
}
// Строки верхней таблицы: код ПУП, номер ТС, статус.
async function scanRows() {
  await closePreview();
  const rows = new Map();
  const grab = () => {
    for (const el of pupCodeEls()) {
      const code = norm(el.textContent);
      if (rows.has(code)) continue;
      rows.set(code, rowInfo(el));
    }
  };
  grab();
  const any = pupCodeEls()[0];
  if (any) for (const sc of scrollerChain(any)) {
    sc.scrollTop = 0; await sleep(300);
    for (let i = 0; i < 120; i++) {
      grab();
      const maxTop = sc.scrollHeight - sc.clientHeight;
      if (sc.scrollTop >= maxTop - 2) break;
      sc.scrollTop = Math.min(maxTop, sc.scrollTop + Math.max(30, Math.floor(sc.clientHeight * 0.5)));
      await sleep(250);
    }
    grab(); sc.scrollTop = 0;
  }
  return [...rows.values()];
}

// Команды от вкладки приёмки приходят через chrome.storage (работает, даже если панель закрыта).
let lastCmdId = null;
async function handleCmd(cmd) {
  if (!cmd || cmd.id === lastCmdId || !isList()) return;
  if (cmd.type === "CANCEL") { cancelCollect = true; return; }
  lastCmdId = cmd.id;
  const reply = r => chrome.storage.local.set({ [SSCC_RES_KEY]: { id: cmd.id, ...r } });
  await reply({ stage: "ack", ok: true });
  try {
    if (cmd.type === "OPEN_AND_COLLECT") {
      const o = await openPreview(cmd.code);
      if (!o.ok) return reply({ stage: "done", ok: false, error: o.error });
      const r = await collectGrid(null);
      return reply({ stage: "done", ok: true, codes: r.codes, expected: r.expected, problem: r.problem, pages: r.pages });
    }
    return reply({ stage: "done", ok: false, error: "Неизвестная команда" });
  } catch (e) {
    return reply({ stage: "done", ok: false, error: String(e && e.message) === CANCELLED ? "Сбор остановлен пользователем." : String(e) });
  }
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch[SSCC_CMD_KEY]) handleCmd(ch[SSCC_CMD_KEY].newValue); });

// =====================================================================
//  СТРАНИЦА ПРИЁМКИ (RDT): распознавание экрана и действия
// =====================================================================
function findButton(re) {
  const els = document.querySelectorAll('button,input[type=button],input[type=submit],a,[role=button],div,span,td,li,p');
  let best = null;
  for (const e of els) {
    const t = norm(e.tagName === "INPUT" ? e.value : e.textContent);
    if (!re.test(t) || !vis(e)) continue;
    // берём самый вложенный элемент с таким текстом
    if ([...e.children].some(c => re.test(norm(c.textContent)) && vis(c))) continue;
    best = best || e;
  }
  return best;
}

function editableInputs() {
  return [...document.querySelectorAll("input,textarea")].filter(e =>
    vis(e) && !e.disabled && !e.readOnly && !/^(hidden|checkbox|radio|button|submit|image|file)$/i.test(e.type || ""));
}
// Редактируемое поле, стоящее после подписи (например «SSCC» или «Номер ТС»).
function inputAfterLabel(re) {
  const inputs = editableInputs();
  if (!inputs.length) return null;
  const labels = [...document.querySelectorAll("div,span,td,label,p,b,li")]
    .filter(e => vis(e) && re.test(norm(e.textContent)) && ![...e.children].some(c => re.test(norm(c.textContent))));
  for (const lb of labels) {
    const nxt = inputs.find(i => !lb.contains(i) && (lb.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_FOLLOWING));
    if (nxt) return nxt;
  }
  return null; // без нужной подписи поле не считаем подходящим — так мы не впишем номер в чужое поле
}
const findSsccInput = () => inputAfterLabel(/^SSCC$/);

function dialogText(okBtn) {
  let p = okBtn.parentElement;
  for (let i = 0; i < 5 && p; i++, p = p.parentElement) {
    const t = norm(p.innerText).replace(/(?:^|\s)(ок|ok)$/i, "").trim();
    if (t.length > 2) return t;
  }
  return "";
}

// Варианты в списке «ТС и ПУП»:  «E054OE35 / 55282_1833077_41907 / 0 / 48 / -1»
const OPT_RE = /^(\S+)\s*\/\s*(\S+)\s*\/\s*(\d+)\s*\/\s*(\d+)\s*\/\s*-?\d+$/;
function readOptions() {
  const out = [];
  for (const e of document.querySelectorAll("div,span,li,option,td,p,a,button")) {
    const m = OPT_RE.exec(norm(e.textContent));
    if (!m || (e.tagName !== "OPTION" && !vis(e))) continue;
    if ([...e.children].some(c => OPT_RE.test(norm(c.textContent)))) continue;
    out.push({ el: e, plate: m[1], code: m[2], acc: +m[3], total: +m[4], text: norm(e.textContent) });
  }
  return out;
}
function chooseOption(o) {
  if (o.el.tagName === "OPTION") {
    const sel = o.el.closest("select");
    sel.value = o.el.value; sel.dispatchEvent(new Event("input", { bubbles: true })); sel.dispatchEvent(new Event("change", { bubbles: true }));
  } else realClick(o.el);
}

function screen() {
  const txt = norm(document.body ? document.body.innerText : "");
  const noBtn = findButton(/^нет$/i);
  if (/Регистрация груза произведена успешно/i.test(txt) && noBtn) return { kind: "success", label: "окно печати", noBtn };
  const okBtn = findButton(/^(ок|ok)$/i);
  if (okBtn) return { kind: "dialog", label: "сообщение", okBtn, message: dialogText(okBtn) };
  const send = findButton(/^отправить$/i);
  const input = findSsccInput();
  // сведения о выбранном ТС/ПУП (экран «Номер ПУП … Всего П/Е … Отправить»)
  if (/Номер ПУП/i.test(txt) && /Всего\s*П\/Е/i.test(txt) && send && !input) {
    const a = /Принято\s*П\/Е\s*(\d+)\s*Всего\s*П\/Е\s*(\d+)/i.exec(txt), c = /Номер ПУП\s+(\S+)/i.exec(txt);
    return { kind: "info", label: "сведения о ТС и ПУП", send, code: c ? c[1] : "", accepted: a ? +a[1] : null, total: a ? +a[2] : null };
  }
  if (/Выберите ТС и ПУП/i.test(txt)) return { kind: "select", label: "выбор ТС и ПУП", opts: readOptions() };
  if (input && send && !/принтер/i.test(txt)) {
    const m = txt.match(/Принято\s*П\/Е\s*(\d+)\s*\/\s*(\d+)/i);
    return { kind: "ready", label: "ввод SSCC", input, send, counter: m ? +m[1] : null, total: m ? +m[2] : null };
  }
  const tcIn = inputAfterLabel(/^Номер ТС$/);
  if (tcIn && send && !input) return { kind: "tcentry", label: "ввод номера ТС", input: tcIn, send };
  const h = txt.match(/Приемка ПУП\s*-\s*\d+\/\d+/i);
  return { kind: "other", label: "другой экран" + (h ? " (" + h[0] + ")" : "") };
}

function setValue(el, v) {
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  el.focus();
  Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

// ---------- Управление циклом ----------
const ctl = { running: false, paused: false, cmd: null, resume: null };

async function setRun(run, message) {
  await ssccMutate(s => { s.run = run; if (message !== undefined) s.message = message; });
}
async function patchItem(sscc, patch, logText) {
  await ssccMutate(s => {
    const it = s.items.find(i => i.sscc === sscc);
    if (it) Object.assign(it, patch);
    if (logText) ssccLog(s, logText);
  });
}
async function fatal(sscc, status, msg) {
  await ssccMutate(s => {
    const it = s.items.find(i => i.sscc === sscc);
    if (it) { it.status = status; it.end = Date.now(); it.msg = msg; }
    s.run = "error"; s.message = msg;
    ssccLog(s, "СТОП: " + msg);
  });
  return { fatal: true };
}

async function processOne(it) {
  const code = it.sscc;
  let sc = await waitFor(() => { const x = screen(); return x.kind === "ready" ? x : null; }, T_READY);
  if (!sc) { const x = screen(); return fatal(code, "queued", "Форма приёмки не готова к вводу. Сейчас: " + x.label + (x.message ? " — «" + x.message + "»" : "") + ". Ничего не отправлено."); }
  const before = sc.counter;
  setValue(sc.input, "");
  setValue(sc.input, code);
  if (sc.input.value !== code) return fatal(code, "queued", "Не удалось вставить номер в поле SSCC. Ничего не отправлено.");
  const send = findButton(/^отправить$/i);
  if (!send) return fatal(code, "queued", "Не найдена кнопка «Отправить». Ничего не отправлено.");

  // Помечаем «в обработке» ДО нажатия — защита от повторной отправки при сбое.
  await patchItem(code, { status: "processing", start: Date.now(), msg: "" }, "Отправка: " + code);
  send.click();

  const out = await waitFor(() => {
    const x = screen();
    if (x.kind === "success" || x.kind === "dialog") return x;
    if (x.kind === "ready" && x.input.value === "" && before != null && x.counter != null && x.counter > before) return { kind: "success-noprint" };
    return null;
  }, T_RESULT);

  if (!out) return fatal(code, "error", "Нет ответа от формы за " + T_RESULT / 1000 + " сек. Результат по " + code + " неизвестен — проверьте вручную. Следующие номера не отправлялись.");

  if (out.kind === "success" || out.kind === "success-noprint") {
    await patchItem(code, { status: "ok", end: Date.now(), msg: "" }, "Успешно: " + code);
    await ssccMutate(s => { const c = code.slice(-18); if (!s.history.includes(c)) s.history.push(c); if (s.history.length > 1000) s.history.shift(); });
    if (out.kind === "success") out.noBtn.click();
    const back = await waitFor(() => { const x = screen(); return (x.kind === "ready" || x.kind === "tcentry") ? x : null; }, T_BACK);
    if (!back) { const x = screen(); return fatal(code, "ok", "Номер " + code + " принят, но форма не вернулась на ввод SSCC (сейчас: " + x.label + "). Проверьте экран."); }
    return { fatal: false };
  }

  // диалог с сообщением
  const msg = out.message || "(пустое сообщение)";
  const known = KNOWN_NOTFOUND.some(re => re.test(msg)) && !/принтер/i.test(msg);
  if (!known) return fatal(code, "error", "Неизвестная ошибка формы: «" + msg + "». Кнопки не нажимались, следующие номера не отправлялись.");
  await patchItem(code, { status: "notfound", end: Date.now(), msg: msg }, "Не найден / повторный: " + code + " — «" + msg + "»");
  out.okBtn.click();
  const back = await waitFor(() => { const x = screen(); return (x.kind === "ready" || x.kind === "tcentry") ? x : null; }, T_BACK);
  if (!back) { const x = screen(); return fatal(code, "notfound", "После «Ок» форма не вернулась на ввод SSCC (сейчас: " + x.label + "). Проверьте экран."); }
  setValue(back.input, "");
  return { fatal: false };
}

async function loop(onlyOne) {
  ctl.running = true; ctl.cmd = null;
  await ssccMutate(s => { s.run = "running"; s.message = onlyOne ? "Тест одного номера" : ""; ssccLog(s, onlyOne ? "Старт: тест 1 номера" : "Старт обработки"); });
  let done = 0;
  try {
    for (;;) {
      const s = await ssccLoad();
      const next = s.items.find(i => i.status === "queued");
      if (!next) { await ssccMutate(x => { x.run = "done"; x.message = "Партия завершена. Результаты сохранены. При сборе следующей таблицы партия автоматически уйдёт в архив."; ssccLog(x, "Партия завершена"); }); break; }
      if (ctl.cmd === "stop") { await setRun("stopped", "Остановлено пользователем"); await ssccMutate(x => ssccLog(x, "Стоп")); break; }
      if (ctl.cmd === "pause") {
        await setRun("paused", "Пауза");
        await ssccMutate(x => ssccLog(x, "Пауза"));
        ctl.paused = true;
        await new Promise(r => { ctl.resume = r; });
        ctl.paused = false; ctl.resume = null;
        if (ctl.cmd === "stop") { await setRun("stopped", "Остановлено пользователем"); break; }
        ctl.cmd = null;
        await setRun("running", "");
        await ssccMutate(x => ssccLog(x, "Продолжение"));
        continue;
      }
      if (onlyOne && done >= 1) { await setRun("stopped", "Тест завершён: принят 1 номер. Проверьте результат и нажмите «НАЧАТЬ» для остальных."); break; }
      const res = await processOne(next);
      if (res.fatal) break;
      done++;
      await sleep(300);
    }
  } catch (e) {
    await ssccMutate(s => { s.run = "error"; s.message = "Внутренняя ошибка: " + e; ssccLog(s, "СТОП: внутренняя ошибка " + e); });
  } finally {
    ctl.running = false; ctl.paused = false; ctl.resume = null; ctl.cmd = null;
  }
}

// При загрузке страницы приёмки: если прошлый запуск не завершён — безопасно остановить.
async function reconcile() {
  if (isList()) { await ssccMutate(x => { if (x.run === "collecting") { x.run = "stopped"; x.message = "Страница списка обновилась во время сбора — остановлено."; ssccLog(x, x.message); } }); return; }
  if (!isRdt()) return;
  await ssccMutate(s => {
    let touched = false;
    for (const it of s.items) if (it.status === "processing") { it.status = "error"; it.end = Date.now(); it.msg = "Страница обновилась во время отправки — результат неизвестен, проверьте вручную"; touched = true; }
    if (s.run === "running" || s.run === "pausing" || s.run === "paused") { s.run = "stopped"; s.message = "Страница приёмки была обновлена — обработка остановлена."; touched = true; }
    if (s.tc && s.tc.active) { s.tc.active = false; for (const j of s.tc.jobs) if (j.status === "collecting" || j.status === "receiving") { j.status = "queued"; j.msg = "Прерван обновлением страницы — будет повторён"; } touched = true; }
    if (touched) ssccLog(s, s.message);
  });
}

// ---------- Режим по ТС: вкладка приёмки ----------
const jobPatch = (s, code, patch) => { const j = s.tc.jobs.find(x => x.code === code); if (j) Object.assign(j, patch); };
async function tcFail(job, msg, status) {
  await ssccMutate(s => { jobPatch(s, job.code, { status: status || "error", msg }); s.tc.active = false; s.run = "error"; s.message = msg; ssccLog(s, "СТОП (ТС " + job.plate + "): " + msg); });
  return { fatal: true };
}
async function checkpoint() {
  if (ctl.cmd === "stop") return "stop";
  if (ctl.cmd === "pause") {
    await setRun("paused", "Пауза"); await ssccMutate(x => ssccLog(x, "Пауза"));
    ctl.paused = true;
    await new Promise(r => { ctl.resume = r; });
    ctl.paused = false; ctl.resume = null;
    if (ctl.cmd === "stop") return "stop";
    ctl.cmd = null; await setRun("running", ""); await ssccMutate(x => ssccLog(x, "Продолжение"));
  }
  return "go";
}
async function userStopped() {
  await ssccMutate(s => { s.run = "stopped"; s.message = "Остановлено пользователем. Незавершённые ТС можно продолжить кнопкой «Продолжить»."; s.tc.active = false; ssccLog(s, "Стоп"); });
}
// Запрос к вкладке списка через storage.
async function askList(cmd, timeout) {
  const id = Date.now() + "-" + Math.random().toString(36).slice(2, 8);
  await chrome.storage.local.set({ [SSCC_CMD_KEY]: { id, ...cmd } });
  const t0 = Date.now();
  let acked = false;
  for (;;) {
    const r = (await chrome.storage.local.get(SSCC_RES_KEY))[SSCC_RES_KEY];
    if (r && r.id === id) { if (r.stage === "ack") acked = true; else return r; }
    if (!acked && Date.now() - t0 > 8000) return { ok: false, error: "Вкладка списка ПУП не отвечает. Обновите её (F5) и запустите снова." };
    if (Date.now() - t0 > (timeout || 240000)) return { ok: false, error: "Вкладка списка не ответила вовремя." };
    if (ctl.cmd === "stop") { await chrome.storage.local.set({ [SSCC_CMD_KEY]: { id: id + "-cancel", type: "CANCEL" } }); }
    await sleep(400);
  }
}

// Номер ТС → выбор нужного ПУП → экран сведений → «Отправить» → экран ввода SSCC.
async function tcEnter(job) {
  const sc = await waitFor(() => { const x = screen(); return x.kind === "tcentry" ? x : null; }, T_READY);
  if (!sc) { const x = screen(); return tcFail(job, "Форма не на экране ввода номера ТС (сейчас: " + x.label + (x.message ? " — «" + x.message + "»" : "") + ")."); }
  setValue(sc.input, ""); setValue(sc.input, job.digits);
  if (sc.input.value !== job.digits) return tcFail(job, "Не удалось ввести цифры номера ТС в поле.");
  const send = findButton(/^отправить$/i);
  if (!send) return tcFail(job, "Не найдена кнопка «Отправить» на экране ввода ТС.");
  send.click();
  const out = await waitFor(() => { const x = screen(); return ["select", "info", "ready", "dialog"].includes(x.kind) ? x : null; }, T_RESULT);
  if (!out) return tcFail(job, "Нет ответа формы после ввода номера ТС (" + job.digits + ").");
  if (out.kind === "dialog") {
    if (/машин\S*\s+не\s+найден/i.test(out.message)) {
      out.okBtn.click();
      await waitFor(() => { const x = screen(); return x.kind === "tcentry" ? x : null; }, T_BACK);
      await ssccMutate(s => { jobPatch(s, job.code, { status: "skipped", msg: "Машина не найдена (цифры " + job.digits + ")" }); s.items = []; ssccLog(s, "ТС " + job.plate + ": «Машина не найдена» — пропущен"); });
      return { skipped: true };
    }
    return tcFail(job, "Неизвестное сообщение формы после ввода ТС: «" + out.message + "». Кнопки не нажимались.");
  }
  if (out.kind === "ready") return tcFail(job, "Форма сразу перешла на ввод SSCC без выбора ПУП — нужный ПУП не подтверждён. Остановка.");
  let inf = out;
  if (out.kind === "select") {
    let x = out;
    if (!x.opts.length) {
      const field = findButton(/^ТС и ПУП не выбраны$/i);
      if (!field) return tcFail(job, "Не найдено поле выбора «ТС и ПУП не выбраны».");
      realClick(field);
      x = await waitFor(() => { const y = screen(); return y.kind === "select" && y.opts.length ? y : null; }, T_BACK);
      if (!x) return tcFail(job, "Список вариантов ТС/ПУП не открылся.");
    }
    const m = x.opts.filter(o => o.code === job.code);
    if (m.length !== 1) return tcFail(job, "В списке вариантов " + (m.length ? "ПУП " + job.code + " встречается " + m.length + " раза" : "нет нужного ПУП " + job.code) + ". Варианты: " + x.opts.map(o => o.text).join(" | ") + ". Ничего не выбрано.");
    chooseOption(m[0]);
    inf = await waitFor(() => { const y = screen(); return y.kind === "info" ? y : null; }, T_RESULT);
    if (!inf) return tcFail(job, "После выбора ПУП не открылся экран сведений.");
  }
  if (inf.kind !== "info") return tcFail(job, "Неожиданный экран после ввода ТС: " + inf.label + ".");
  if (inf.code !== job.code) return tcFail(job, "Выбран другой ПУП: " + inf.code + " вместо " + job.code + ". Остановка.");
  const need = (inf.total != null && inf.accepted != null) ? inf.total - inf.accepted : null;
  const qn = (await ssccLoad()).items.filter(i => i.status === "queued").length;
  if (need != null && need <= 0) return tcFail(job, "ПУП " + job.code + " уже принят полностью (" + inf.accepted + "/" + inf.total + ").", "skipped");
  await ssccMutate(s => { jobPatch(s, job.code, { accepted: inf.accepted, total: inf.total, msg: need != null && qn !== need ? "Внимание: к приёмке " + need + ", собрано SSCC: " + qn : "" }); if (need != null && qn !== need) ssccLog(s, "ТС " + job.plate + ": к приёмке " + need + ", собрано SSCC " + qn); });
  inf.send.click();
  const nx = await waitFor(() => { const y = screen(); return ["ready", "dialog"].includes(y.kind) ? y : null; }, T_RESULT);
  if (!nx || nx.kind !== "ready") return tcFail(job, nx ? "После экрана сведений появилось сообщение: «" + nx.message + "». Кнопки не нажимались." : "После экрана сведений не открылся ввод SSCC.");
  return { ok: true };
}

async function receiveQueue(job) {
  for (;;) {
    if ((await checkpoint()) === "stop") { await userStopped(); return { stopped: true }; }
    const s = await ssccLoad();
    const next = s.items.find(i => i.status === "queued");
    if (!next) break;
    const res = await processOne(next);
    if (res.fatal) { await ssccMutate(x => { jobPatch(x, job.code, { status: "error", msg: x.message }); x.tc.active = false; }); return { fatal: true }; }
    await sleep(300);
  }
  const fin = await waitFor(() => { const x = screen(); return x.kind === "tcentry" ? x : null; }, T_BACK);
  const st = await ssccLoad();
  const cnt = k => st.items.filter(i => i.status === k).length;
  if (fin) {
    await ssccMutate(s => { jobPatch(s, job.code, { status: "done", ok: cnt("ok"), notfound: cnt("notfound"), errors: cnt("error") }); ssccLog(s, "ТС " + job.plate + " / " + job.code + ": готово (принято " + cnt("ok") + ", не найдено " + cnt("notfound") + ")"); });
    return {};
  }
  const x = screen();
  await tcFail(job, "ТС " + job.plate + ": все собранные SSCC отправлены, но форма не вернулась на ввод номера ТС (сейчас: " + x.label + (x.kind === "ready" && x.counter != null ? ", принято " + x.counter + " из " + x.total : "") + "). Приём может быть неполным — проверьте экран. Остановка.", "incomplete");
  return { fatal: true };
}

async function tcRun() {
  ctl.running = true; ctl.cmd = null;
  await ssccMutate(s => { s.run = "running"; s.message = ""; s.tc.active = true; ssccLog(s, "Режим по ТС: старт"); });
  try {
    for (;;) {
      if ((await checkpoint()) === "stop") { await userStopped(); return; }
      const s0 = await ssccLoad();
      const job = s0.tc.jobs.find(j => j.status === "receiving") || s0.tc.jobs.find(j => j.status === "queued");
      if (!job) { await ssccMutate(s => { s.run = "done"; s.tc.active = false; s.message = "Все выбранные ТС обработаны. Итоги — в списке ТС."; ssccLog(s, s.message); }); return; }
      const resume = job.status === "receiving" && screen().kind === "ready" && s0.items.some(i => i.status === "queued");
      if (!resume) {
        await ssccMutate(s => { jobPatch(s, job.code, { status: "collecting", msg: "" }); s.items = []; ssccLog(s, "ТС " + job.plate + " / " + job.code + ": сбор SSCC"); });
        const res = await askList({ type: "OPEN_AND_COLLECT", code: job.code });
        if (!res || !res.ok) { await tcFail(job, "Сбор SSCC для " + job.code + ": " + ((res && res.error) || "нет ответа")); return; }
        if (res.problem) { await tcFail(job, "Сбор SSCC для " + job.code + " неполный: " + res.problem); return; }
        if ((await checkpoint()) === "stop") { await ssccMutate(s => jobPatch(s, job.code, { status: "queued" })); await userStopped(); return; }
        const hist = new Set((await ssccLoad()).history);
        const fresh = res.codes.filter(c => !c.confirmed && !hist.has(c.sscc.slice(-18)));
        if (!fresh.length) { await ssccMutate(s => { jobPatch(s, job.code, { status: "skipped", msg: "Нет неподтверждённых паллет" }); ssccLog(s, "ТС " + job.plate + ": нет неподтверждённых паллет — пропущен"); }); continue; }
        await ssccMutate(s => { s.items = fresh.map((c, i) => ({ n: i + 1, sscc: c.sscc, pallet: c.pallet, status: "queued", start: 0, end: 0, msg: "" })); jobPatch(s, job.code, { collected: fresh.length }); });
        let r;
        if (job.noEnter) { r = screen().kind === "ready" ? { ok: true } : await tcFail(job, "Форма должна стоять на вводе SSCC («Приемка ПУП - 3/7»). Сейчас: " + screen().label + "."); }
        else r = await tcEnter(job);
        if (r.fatal) return;
        if (r.skipped) continue;
        await ssccMutate(s => jobPatch(s, job.code, { status: "receiving" }));
      }
      const rr = await receiveQueue(job);
      if (rr.fatal || rr.stopped) return;
    }
  } catch (e) {
    await ssccMutate(s => { s.run = "error"; s.message = "Внутренняя ошибка: " + e; s.tc.active = false; ssccLog(s, "СТОП: внутренняя ошибка " + e); });
  } finally {
    ctl.running = false; ctl.paused = false; ctl.resume = null; ctl.cmd = null;
  }
}

// ---------- Полная автоматизация (страница списка): сбор всех страниц → старт приёмки ----------
let fullBusy = false;
async function fullAuto() {
  fullBusy = true;
  const prog = t => setRun("collecting", t);
  try {
    await ssccMutate(x => { x.run = "collecting"; x.message = "Полная автоматизация: идёт сбор…"; ssccLog(x, "Полная автоматизация: старт сбора"); });
    const r = await collectGrid(prog);
    const add = await ssccAddCodes(r.codes, "Полная автоматизация: сбор (" + r.pages + " стр.)");
    if (add.blocked) { await setRun("error", "Предыдущая партия не закрыта. Приёмка не запускалась."); return; }
    const sum = "Найдено в таблице: " + r.codes.length + (r.expected != null ? " из " + r.expected : "") + ", добавлено в очередь: " + add.added +
      (add.dup ? ", уже в очереди: " + add.dup : "") + (add.prev ? ", принято ранее: " + add.prev : "") + (add.over ? ", сверх лимита: " + add.over : "") + ". Страниц: " + r.pages + ".";
    if (r.problem) { await setRun("error", "СБОР НЕПОЛНЫЙ. " + r.problem + "\n" + sum + "\nПриёмка не запускалась. Проверьте очередь: «НАЧАТЬ ПРИЁМКУ» примет только собранное."); return; }
    const st = await ssccLoad();
    if (!st.items.some(i => i.status === "queued")) { await setRun("error", "Нет новых номеров для приёмки.\n" + sum); return; }
    await setRun("collecting", sum + "\nЗапускаю приёмку…");
    const resp = await chrome.runtime.sendMessage({ type: "RELAY_START" });
    if (!resp || !resp.ok) await setRun("error", sum + "\nПриёмка не запущена: " + ((resp && resp.error) || "нет ответа") + ". Приведите форму к экрану ввода SSCC и нажмите «НАЧАТЬ ПРИЁМКУ».");
  } catch (e) {
    if (String(e && e.message) === CANCELLED) await setRun("stopped", "Сбор остановлен пользователем. Приёмка не запускалась.");
    else await setRun("error", "Полная автоматизация: внутренняя ошибка " + e);
  } finally { fullBusy = false; }
}

// ---------- ПОЛНАЯ АВТОМАТИЗАЦИЯ: все ТС списка со статусом «Не подтверждено», по очереди ----------
let fullAllBusy = false;
async function fullAutoAll() {
  fullAllBusy = true; cancelCollect = false;
  try {
    await ssccMutate(x => { x.items = []; x.tc.jobs = []; x.run = "collecting"; x.message = "Полная автоматизация: читаю список ТС…"; ssccLog(x, "Полная автоматизация: чтение списка ТС"); });
    const rows = await scanRows();
    const isTodo = w => /не\s*подтвержден/i.test(w.status);
    const todo = rows.filter(w => isTodo(w) && /\d/.test(w.plate || ""));
    const noPlate = rows.filter(w => isTodo(w) && !/\d/.test(w.plate || ""));
    if (!todo.length) { await setRun("error", "В списке нет ТС со статусом «Не подтверждено»" + (noPlate.length ? " (у " + noPlate.length + " строк не определён номер ТС)" : "") + ". Приёмка не запускалась."); return; }
    const jobs = todo.map(w => ({ code: w.code, plate: w.plate, digits: (w.plate.match(/\d+/) || [""])[0], status: "queued", msg: "" }));
    await ssccMutate(x => {
      x.tc.rows = rows; x.tc.selected = todo.map(w => w.code); x.tc.jobs = jobs;
      x.run = "collecting"; x.message = "Найдено ТС к приёмке: " + jobs.length + ". Запускаю…";
      ssccLog(x, "Полная автоматизация: ТС к приёмке " + jobs.length + (noPlate.length ? ", без номера ТС (пропущены): " + noPlate.length : ""));
    });
    const resp = await chrome.runtime.sendMessage({ type: "RELAY", msg: { type: "START_TC" } });
    if (!resp || !resp.ok) await setRun("error", "ТС найдены (" + jobs.length + "), но приёмка не запущена: " + ((resp && resp.error) || "нет ответа") + ". Верните форму на ввод номера ТС («Приемка ПУП - 1/7») и нажмите «Продолжить».");
  } catch (e) {
    if (String(e && e.message) === CANCELLED) await setRun("stopped", "Остановлено пользователем.");
    else await setRun("error", "Полная автоматизация: внутренняя ошибка " + e);
  } finally { fullAllBusy = false; }
}

// ---------- Сообщения от панели ----------
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    switch (m && m.type) {
      case "PING": return { ok: true, role: isRdt() ? "rdt" : isList() ? "list" : "other", version: SSCC_VERSION };
      case "COLLECT": {
        if (!isList()) return { ok: false, error: "Это не страница списка ПУП." };
        return { ok: true, ...collectVisible("view") };
      }
      case "COLLECT_ALL": {
        if (!isList()) return { ok: false, error: "Это не страница списка ПУП." };
        if (fullBusy) return { ok: false, error: "Автоматизация уже идёт." };
        const st = await ssccLoad();
        if (["running", "pausing", "paused", "collecting"].includes(st.run)) return { ok: false, error: "Во время приёмки собирать номера нельзя." };
        let r;
        try { r = await collectGrid(null); } catch (e) { return { ok: false, error: String(e && e.message) === CANCELLED ? "Сбор остановлен." : String(e) }; }
        const add = await ssccAddCodes(r.codes, "Сбор всей таблицы (" + r.pages + " стр.)");
        if (add.blocked) return { ok: false, error: "Предыдущая партия ещё не закрыта: остались необработанные номера или есть ошибки с неизвестным результатом. Завершите её либо проверьте номера и нажмите «Сбросить партию». Новые SSCC не добавлены." };
        return { ok: true, scrolled: r.pages > 0, pages: r.pages, expected: r.expected, problem: r.problem, ...add };
      }
      case "FULL_AUTO": {
        if (!isList()) return { ok: false, error: "Это не страница списка ПУП." };
        if (fullBusy) return { ok: false, error: "Автоматизация уже идёт." };
        const st = await ssccLoad();
        if (["running", "pausing", "paused", "collecting"].includes(st.run)) return { ok: false, error: "Сейчас уже что-то выполняется. Нажмите СТОП." };
        if (st.items.some(i => i.status === "processing" || i.status === "error")) return { ok: false, error: "В предыдущей партии есть номер с неизвестным результатом. Проверьте его вручную и нажмите «Сбросить партию»." };
        if (st.items.some(i => i.status !== "queued") && st.items.some(i => i.status === "queued")) return { ok: false, error: "Предыдущая партия остановлена и содержит необработанные номера. Продолжите её кнопкой «Продолжить» или нажмите «Сбросить партию»." };
        fullAuto();
        return { ok: true };
      }
      case "CANCEL": { cancelCollect = true; return { ok: true }; }
      case "FULL_AUTO_ALL": {
        if (!isList()) return { ok: false, error: "Это не страница списка ПУП." };
        if (fullAllBusy) return { ok: false, error: "Автоматизация уже идёт." };
        const st = await ssccLoad();
        if (["running", "pausing", "paused", "collecting"].includes(st.run)) return { ok: false, error: "Сейчас уже что-то выполняется. Нажмите СТОП." };
        fullAutoAll();
        return { ok: true };
      }
      case "GET_OPEN": {
        if (!isList()) return { ok: false, error: "Это не страница списка ПУП." };
        try { return await getOpenPup(); } catch (e) { return { ok: false, error: String(e) }; }
      }
      case "SCAN_ROWS": {
        if (!isList()) return { ok: false, error: "Это не страница списка ПУП." };
        cancelCollect = false;
        try { return { ok: true, rows: await scanRows() }; } catch (e) { return { ok: false, error: String(e) }; }
      }
      case "START_TC": {
        if (!isRdt()) return { ok: false, error: "Это не страница приёмки." };
        if (ctl.running && ctl.paused) { ctl.cmd = null; ctl.resume(); return { ok: true }; }
        if (ctl.running) return { ok: false, error: "Обработка уже идёт." };
        if (document.visibilityState !== "visible") return { ok: false, error: "Вкладка приёмки скрыта или свёрнута. Выведите её на экран и повторите." };
        const st = await ssccLoad();
        if (!st.tc.jobs.some(j => j.status === "queued" || j.status === "receiving")) return { ok: false, error: "Не выбрано ни одного ТС." };
        const x = screen();
        const okScreen = x.kind === "tcentry" || (x.kind === "ready" && st.tc.jobs.some(j => j.status === "receiving" || (j.status === "queued" && j.noEnter)));
        if (!okScreen) return { ok: false, error: "Форма приёмки должна стоять на вводе номера ТС («Приемка ПУП - 1/7»). Сейчас: " + x.label + "." };
        tcRun();
        return { ok: true };
      }
      case "PROBE": {
        if (!isRdt()) return { ok: false, error: "Это не страница приёмки." };
        const x = screen();
        return { ok: true, kind: x.kind, label: x.label, hidden: document.visibilityState !== "visible" };
      }
      case "START": case "TEST1": {
        if (!isRdt()) return { ok: false, error: "Это не страница приёмки." };
        if (ctl.running && ctl.paused) { ctl.cmd = null; ctl.resume(); return { ok: true }; }
        if (ctl.running) return { ok: false, error: "Обработка уже идёт." };
        if (document.visibilityState !== "visible") return { ok: false, error: "Вкладка приёмки скрыта или свёрнута. Выведите её на экран и повторите." };
        const s = await ssccLoad();
        if (!s.items.some(i => i.status === "queued")) return { ok: false, error: "В очереди нет номеров." };
        const x = screen();
        if (x.kind !== "ready") return { ok: false, error: "Форма приёмки не на экране ввода SSCC (сейчас: " + x.label + (x.message ? " — «" + x.message + "»" : "") + "). Приведите её к экрану ввода SSCC." };
        loop(m.type === "TEST1");
        return { ok: true };
      }
      case "PAUSE": {
        if (!ctl.running || ctl.paused) return { ok: false, error: "Сейчас не выполняется." };
        ctl.cmd = "pause";
        await setRun("pausing", "Пауза после завершения текущего номера…");
        return { ok: true };
      }
      case "STOP": {
        if (!ctl.running) { await setRun("stopped", "Остановлено пользователем"); return { ok: true }; }
        ctl.cmd = "stop";
        if (ctl.paused && ctl.resume) ctl.resume();
        else await ssccMutate(s => { s.message = "Остановка после завершения текущего номера…"; });
        return { ok: true };
      }
    }
    return { ok: false, error: "Неизвестная команда" };
  })().then(reply, e => reply({ ok: false, error: String(e) }));
  return true;
});

reconcile();
})();
