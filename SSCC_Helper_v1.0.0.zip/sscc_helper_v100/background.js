// Передаёт команду «старт приёмки» на вкладку приёмки после автосбора (панель к этому моменту может быть закрыта).
const sleep = ms => new Promise(r => setTimeout(r, ms));
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || (m.type !== "RELAY_START" && m.type !== "RELAY")) return false;
  const fwd = m.type === "RELAY" ? m.msg : { type: "START" };
  (async () => {
    const all = await chrome.tabs.query({});
    const rdts = all.filter(t => {
      try { const u = new URL(t.url); return u.hostname.endsWith("x5.ru") && u.hostname.startsWith("rdt.") && u.pathname.includes("/pages/rdt/"); }
      catch (e) { return false; }
    });
    if (rdts.length !== 1) return { ok: false, error: rdts.length ? "открыто несколько вкладок приёмки" : "вкладка приёмки не найдена" };
    const id = rdts[0].id;
    try { const p = await chrome.tabs.sendMessage(id, { type: "PING" }); if (!p || !p.ok) throw 0; }
    catch (e) {
      try { await chrome.scripting.executeScript({ target: { tabId: id }, files: ["common.js", "content.js"] }); await sleep(300); }
      catch (e2) { return { ok: false, error: "нет связи со страницей приёмки (обновите её, F5)" }; }
    }
    try { return await chrome.tabs.sendMessage(id, fwd); }
    catch (e) { return { ok: false, error: String(e) }; }
  })().then(reply, e => reply({ ok: false, error: String(e) }));
  return true;
});
