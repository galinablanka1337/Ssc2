const vm=require('vm'),fs=require('fs');
const store={};
const chrome={storage:{local:{async get(k){return {[k]:store[k]};},async set(o){Object.assign(store,o);}}}};
const ctx={chrome,Date,console}; vm.createContext(ctx); vm.runInContext(fs.readFileSync('common.js','utf8'),ctx);
(async()=>{
  let s=await ctx.ssccLoad();
  const codes=Array.from({length:4},(_,i)=>({sscc:String(100000000000000000n+BigInt(i+1)),pallet:'D123456'}));
  let a=await ctx.ssccAddCodes(codes,'SIM normal');
  let b=await ctx.ssccAddCodes([codes[0],{sscc:'200000000000000001',pallet:'D123456'}],'SIM duplicate');
  await ctx.ssccMutate(s=>{s.history.push(codes[1].sscc.slice(-18));});
  let c=await ctx.ssccAddCodes([codes[1],{sscc:'300000000000000001',pallet:'D123456'}],'SIM history');
  await ctx.ssccMutate(s=>{for(let i=0;i<50;i++) s.items.push({sscc:'9'+String(i).padStart(17,'0'),status:'queued'});});
  let d=await ctx.ssccAddCodes([{sscc:'400000000000000001',pallet:''}],'SIM cap');
  console.log(JSON.stringify({normal:a,duplicate:b,history:c,limit:d,items:(await ctx.ssccLoad()).items.length,history:(await ctx.ssccLoad()).history.length},null,2));
})();
