"use strict";
const $ = id => document.getElementById(id);
$("ver").textContent = "v" + SSCC_VERSION;
const STAT = { queued: "в очереди", processing: "В ОБРАБОТКЕ", ok: "успешно", notfound: "не найден/повтор", error: "ОШИБКА", skipped: "пропущен" };
const CLS = { ok: "ok", notfound: "nf", error: "er", skipped: "sk" };
const fmt = t => t ? new Date(t).toLocaleTimeString("ru-RU") : "";
let tabs = { list: null, rdt: null };

function showMsg(text, isErr) { const m = $("msg"); m.textContent = text; m.className = "msg " + (isErr ? "err" : "info"); }

// ---------- вкладки ----------
async function findTabs() {
  const all = await chrome.tabs.query({});
  const lists = [], rdts = [];
  for (const t of all) {
    let u; try { u = new URL(t.url || ""); } catch (e) { continue; }
    if (!u.hostname.endsWith("x5.ru")) continue;
    if (u.hostname.startsWith("rdt.") && u.pathname.includes("/pages/rdt/")) rdts.push(t);
    else if (u.pathname.includes("/advance-notifications")) lists.push(t);
  }
  tabs = { list: lists[0] || null, rdt: rdts[0] || null };
  return { lists, rdts };
}
async function ensureScript(tabId) {
  try { const r = await chrome.tabs.sendMessage(tabId, { type: "PING" }); if (r && r.ok) return true; } catch (e) {}
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["common.js", "content.js"] });
    await new Promise(r => setTimeout(r, 300));
    const r = await chrome.tabs.sendMessage(tabId, { type: "PING" });
    return !!(r && r.ok);
  } catch (e) { return false; }
}
async function send(tabId, msg) {
  if (!(await ensureScript(tabId))) return { ok: false, error: "Нет связи со страницей. Обновите вкладку Nexus (F5) и повторите." };
  try { return await chrome.tabs.sendMessage(tabId, msg); } catch (e) { return { ok: false, error: "Нет связи со страницей: " + e }; }
}

$("find").onclick = async () => {
  const { lists, rdts } = await findTabs();
  let t = "Список ПУП: " + (lists.length ? "найдена ✔" : "НЕ найдена ✖") + "\nПриёмка ПУП: " + (rdts.length ? "найдена ✔" : "НЕ найдена ✖");
  if (rdts.length > 1) t += "\n⚠ Вкладок приёмки несколько (" + rdts.length + "). Оставьте одну.";
  if (lists.length > 1) t += "\n⚠ Вкладок списка несколько (" + lists.length + ").";
  showMsg(t, !lists.length || !rdts.length || rdts.length > 1);
};

// ---------- Полная автоматизация: сбор таблицы + запуск приёмки ----------
$("fullauto").onclick = async () => {
  const btn = $("fullauto");
  btn.disabled = true;
  try {
    const { lists, rdts } = await findTabs();
    if (lists.length !== 1) return showMsg(lists.length ? "Найдено несколько вкладок списка ПУП. Оставьте одну." : "Не найдена вкладка «Уведомления ПУП».", true);
    if (rdts.length !== 1) return showMsg(rdts.length ? "Найдено несколько вкладок приёмки. Оставьте одну." : "Не найдена вкладка приёмки ПУП.", true);
    const active = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!active[0] || active[0].id !== rdts[0].id)
      return showMsg("Для запуска полной автоматизации сначала откройте вкладку приёмки ПУП (экран ввода SSCC), затем нажмите эту кнопку. Список будет собран в фоне.", true);
    const before = await ssccLoad();
    if (["running", "pausing", "paused"].includes(before.run)) return showMsg("Приёмка уже выполняется. Сначала завершите или остановите её.", true);
    if (before.items.some(i => i.status === "processing" || i.status === "error")) return showMsg("В предыдущей партии есть номер с неизвестным результатом. Проверьте его вручную и закройте партию перед новым запуском.", true);
    if (["stopped", "error"].includes(before.run) && before.items.some(i => i.status === "queued")) return showMsg("Предыдущая партия остановлена и содержит необработанные номера. Сначала продолжите её или сбросьте партию.", true);
    if (!confirm("Запустить полный режим?\n\n1. Собрать все SSCC из текущей загруженной таблицы.\n2. Добавить новые номера в очередь.\n3. Начать последовательную приёмку.\n\nПервый запуск рекомендуется делать кнопкой «Тест: принять только 1 номер». Продолжить?")) return;
    showMsg("Шаг 1/2: собираю всю загруженную таблицу. Не закрывайте панель…", false);
    const collected = await send(lists[0].id, { type: "COLLECT_ALL" });
    if (!collected || !collected.ok) return showMsg(collected && collected.error || "Не удалось собрать таблицу.", true);
    let summary = "Собрано: " + collected.found + ", добавлено: " + collected.added +
      ", дубликатов: " + collected.dup + (collected.prev ? ", ранее принято: " + collected.prev : "") +
      (collected.over ? ", сверх лимита: " + collected.over : "");
    if (!collected.scrolled) return showMsg(summary + "\nНе найдено внутреннее окно прокрутки. Автоматический запуск отменён — проверьте таблицу и очередь.", true);
    if (!collected.added && !(await ssccLoad()).items.some(i => i.status === "queued"))
      return showMsg(summary + "\nНовых номеров для приёмки нет.", true);
    const now = await ssccLoad();
    const q = now.items.filter(i => i.status === "queued").length;
    if (!q) return showMsg(summary + "\nОчередь пуста.", true);
    showMsg("Шаг 2/2: " + summary + "\nЗапускаю приёмку " + q + " номеров…", false);
    const started = await send(rdts[0].id, { type: "START" });
    if (!started || !started.ok) return showMsg(summary + "\nСбор выполнен, но запуск приёмки не состоялся: " + (started && started.error || "нет ответа"), true);
    showMsg("Полный режим запущен.\n" + summary + "\nВ очереди на приёмку: " + q + "\nСледите за журналом. При сомнительном результате нажмите СТОП.", false);
  } catch (e) {
    showMsg("Ошибка полного режима: " + e, true);
  } finally {
    btn.disabled = false;
  }
};

// ---------- сбор ----------
$("collectall").onclick = async () => {
  const s0 = await ssccLoad();
  if (["running", "pausing", "paused"].includes(s0.run)) return showMsg("Во время приёмки собирать номера нельзя.", true);
  const [act] = await chrome.tabs.query({ active: true, currentWindow: true });
  let u; try { u = new URL(act.url || ""); } catch (e) { u = null; }
  if (!u || u.hostname.startsWith("rdt.") || !u.pathname.includes("/advance-notifications"))
    return showMsg("Сначала откройте вкладку «Уведомления ПУП» и нажмите кнопку снова.", true);
  showMsg("Идёт сбор: таблица прокручивается сама. Не закрывайте панель и не трогайте таблицу (до ~20 сек)…", false);
  $("collectall").disabled = true;
  const r = await send(act.id, { type: "COLLECT_ALL" });
  $("collectall").disabled = false;
  if (!r || !r.ok) return showMsg(r && r.error || "Не удалось собрать.", true);
  let t = "Найдено в таблице: " + r.found + "\nДобавлено новых: " + r.added + "\nУже в очереди: " + r.dup;
  if (r.prev) t += "\nУже принято ранее (пропущено): " + r.prev;
  if (r.over) t += "\nСверх лимита " + SSCC_LIMIT + " (не добавлено): " + r.over;
  if (!r.scrolled) t += "\n⚠ Внутреннее окно прокрутки не найдено — собраны только видимые. Прокрутите вручную.";
  if (!r.found) t += "\nSSCC не найдены. Откройте таблицу с колонкой SSCC.";
  showMsg(t, !r.found);
};
$("collect").onclick = async () => {
  const s0 = await ssccLoad();
  if (["running", "pausing", "paused"].includes(s0.run)) return showMsg("Во время приёмки собирать номера нельзя.", true);
  const [act] = await chrome.tabs.query({ active: true, currentWindow: true });
  let u; try { u = new URL(act.url || ""); } catch (e) { u = null; }
  if (!u || u.hostname.startsWith("rdt.") || !u.pathname.includes("/advance-notifications"))
    return showMsg("Сначала откройте вкладку «Уведомления ПУП» (список с таблицей) и нажмите кнопку снова.", true);
  const r = await send(act.id, { type: "COLLECT" });
  if (!r || !r.ok) return showMsg(r && r.error || "Не удалось собрать.", true);
  const addedResult = await ssccAddCodes(r.codes, "Сбор видимых номеров");
  if (addedResult.blocked) return showMsg("Предыдущая партия не закрыта: есть необработанные или сомнительные номера. Завершите её либо сбросьте партию перед сбором новой таблицы.", true);
  const { added, dup, prev, over } = addedResult;
  let t = "Найдено видимых: " + r.codes.length + "\nДобавлено новых: " + added + "\nУже в очереди: " + dup;
  if (addedResult.archived) t = "Предыдущая партия сохранена в архиве.\n" + t;
  if (prev) t += "\nУже принято ранее (пропущено): " + prev;
  if (over) t += "\nСверх лимита " + SSCC_LIMIT + " (не добавлено): " + over;
  if (r.mode === "loose") t += "\n⚠ Номера найдены вне распознанной таблицы — проверьте очередь.";
  if (!r.codes.length) t += "\nНа экране нет видимых SSCC. Прокрутите таблицу с номерами.";
  showMsg(t, false);
};

// ---------- приёмка ----------
async function rdtTab() {
  const { rdts } = await findTabs();
  if (!rdts.length) { showMsg("Не найдена вкладка приёмки ПУП (…/pages/rdt/…).", true); return null; }
  if (rdts.length > 1) { showMsg("Открыто несколько вкладок приёмки. Оставьте одну — иначе возможны повторы.", true); return null; }
  return rdts[0];
}
async function startFlow(type) {
  const s = await ssccLoad();
  const q = s.items.filter(i => i.status === "queued").length;
  if (!q) return showMsg("В очереди нет номеров для приёмки.", true);
  if (s.items.some(i => i.status === "processing")) return showMsg("Есть номер «в обработке» с неизвестным результатом. Проверьте его вручную; при обновлении страницы приёмки он станет «ОШИБКА».", true);
  const t = await rdtTab(); if (!t) return;
  const text = type === "TEST1" ? "Принять ТОЛЬКО ОДИН номер для проверки?" : "Принять " + q + " номеров по очереди?\nФорма приёмки должна быть на экране ввода SSCC.";
  if (!confirm(text)) return;
  const r = await send(t.id, { type });
  if (!r || !r.ok) showMsg(r && r.error || "Не удалось запустить.", true);
}
$("start").onclick = () => startFlow("START");
$("test1").onclick = () => startFlow("TEST1");
$("resume").onclick = async () => { const t = await rdtTab(); if (!t) return; const s = await ssccLoad(); if (s.run === "paused") { const r = await send(t.id, { type: "START" }); if (!r.ok) showMsg(r.error, true); } else startFlow("START"); };
$("pause").onclick = async () => { const t = await rdtTab(); if (!t) return; const r = await send(t.id, { type: "PAUSE" }); if (!r.ok) showMsg(r.error, true); };
$("stop").onclick = async () => { const t = await rdtTab(); if (!t) { await ssccMutate(s => { s.run = "stopped"; }); return; } const r = await send(t.id, { type: "STOP" }); if (!r.ok) showMsg(r.error, true); };

// ---------- очистка ----------
const busy = s => ["running", "pausing", "paused"].includes(s.run);
$("clearq").onclick = async () => {
  const s = await ssccLoad(); if (busy(s)) return showMsg("Сначала остановите приёмку.", true);
  if (!confirm("Убрать из очереди все необработанные номера?")) return;
  await ssccMutate(x => { x.items = x.items.filter(i => i.status !== "queued"); x.items.forEach((i, k) => i.n = k + 1); ssccLog(x, "Очередь очищена"); });
};
$("reset").onclick = async () => {
  const s = await ssccLoad(); if (busy(s)) return showMsg("Сначала остановите приёмку.", true);
  if (!confirm("Сбросить текущую партию (очередь и результаты)? Историю принятых номеров это не затрагивает.")) return;
  await ssccMutate(x => {
    if (x.items.length) {
      const closedAt = Date.now();
      x.batches = Array.isArray(x.batches) ? x.batches : [];
      x.batches.push({ id: closedAt, closedAt, result: "manual_reset", total: x.items.length,
        ok: x.items.filter(i => i.status === "ok").length,
        notfound: x.items.filter(i => i.status === "notfound").length,
        errors: x.items.filter(i => i.status === "error").length,
        items: x.items.map(i => ({ ...i })) });
      if (x.batches.length > 100) x.batches.splice(0, x.batches.length - 100);
    }
    x.items = []; x.run = "idle"; x.message = ""; ssccLog(x, "Партия сброшена и сохранена в архиве");
  });
  showMsg("Партия сброшена. Листайте таблицу и собирайте номера. История успешно принятых SSCC сохранена.", false);
};
$("clearhist").onclick = async e => {
  e.preventDefault();
  if (!confirm("Очистить историю ранее принятых номеров? После этого их можно будет собрать и принять снова.")) return;
  await ssccMutate(x => { x.history = []; ssccLog(x, "История принятых очищена"); });
};

// ---------- отрисовка ----------
function render(s) {
  const c = k => s.items.filter(i => i.status === k).length;
  const total = s.items.length, queued = c("queued"), ok = c("ok"), nf = c("notfound"), er = c("error"), sk = c("skipped");
  $("s_total").textContent = total; $("s_queued").textContent = queued; $("s_done").textContent = ok + nf + er + sk;
  $("s_left").textContent = queued; $("s_ok").textContent = ok; $("s_nf").textContent = nf; $("s_er").textContent = er;
  const run = s.run, active = busy(s);
  $("collect").disabled = active; $("fullauto").disabled = active; $("start").disabled = active || !queued; $("test1").disabled = active || !queued;
  $("pause").disabled = run !== "running"; $("resume").disabled = !(run === "paused" || ((run === "stopped" || run === "error") && queued));
  $("stop").disabled = !active; $("clearq").disabled = active; $("reset").disabled = active;
  if (run === "error" || run === "done" || run === "stopped" || run === "pausing" || run === "paused") showMsg(s.message || run, run === "error");
  else if (run === "running") showMsg("Идёт приёмка… " + (ok + nf + er) + " из " + total, false);
  const cur = s.items.find(i => i.status === "processing") || (run !== "idle" ? s.items.find(i => i.status === "queued") : null);
  $("list").innerHTML = s.items.map(i => `<div class="${i === cur ? "cur " : ""}${CLS[i.status] || ""}">${i.n}. ${i.sscc} — ${STAT[i.status]}${i.msg ? " (" + i.msg.slice(0, 60) + ")" : ""}</div>`).join("") || '<div class="sk">пусто</div>';
  $("log").innerHTML = s.log.slice(-40).reverse().map(l => `<div>${fmt(l.t)} ${l.text.replace(/</g, "&lt;")}</div>`).join("");
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch[SSCC_KEY]) render(ch[SSCC_KEY].newValue || ssccBlank()); });
ssccLoad().then(s => { render(s); if (["error", "done", "stopped"].includes(s.run) === false) findTabs(); });
