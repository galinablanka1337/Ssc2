(() => {
"use strict";
if (!chrome.runtime || !chrome.runtime.id) return;

// ---------- Настройки (тайм-ауты и известные ошибки) ----------
const T_READY = 10000;     // ждать готовую форму
const T_RESULT = 20000;    // ждать ответ после «Отправить»
const T_BACK = 15000;      // ждать возврат формы после «Нет» / «Ок»
// Ошибки, которые считаем «SSCC не найден / повторный». Всё остальное = неизвестная ошибка → СТОП.
const KNOWN_NOTFOUND = [/не\s+найден/i, /уже\s+(принят|зарегистр|отсканир|подтвержд)/i, /повторн/i, /дублир/i];

const sleep = ms => new Promise(r => setTimeout(r, ms));
const norm = s => (s || "").replace(/\s+/g, " ").trim();
const isRdt = () => location.hostname.startsWith("rdt.") && location.pathname.includes("/pages/rdt/");
const isList = () => !location.hostname.startsWith("rdt.") && location.pathname.includes("/advance-notifications");

const vis = e => {
  if (!e || !e.isConnected) return false;
  const r = e.getBoundingClientRect(), s = getComputedStyle(e);
  return r.width > 0 && r.height > 0 && s.display !== "none" && s.visibility !== "hidden";
};

async function waitFor(fn, timeout, step = 150) {
  const t0 = Date.now();
  for (;;) {
    const v = fn();
    if (v) return v;
    if (Date.now() - t0 > timeout) return null;
    await sleep(step);
  }
}

// =====================================================================
//  СТРАНИЦА СПИСКА ПУП: сбор видимых SSCC
// =====================================================================
const SSCC_RE = /^(?:\d{18}|\d{20})$/;

function insideViewAndClips(el) {
  const r = el.getBoundingClientRect();
  if (r.width <= 0 || r.height <= 0) return false;
  const cs = getComputedStyle(el);
  if (cs.display === "none" || cs.visibility === "hidden") return false;
  const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  if (cx < 0 || cy < 0 || cx > innerWidth || cy > innerHeight) return false;
  for (let p = el.parentElement; p && p !== document.documentElement; p = p.parentElement) {
    const ps = getComputedStyle(p);
    if (/(auto|scroll|hidden|clip)/.test(ps.overflow + ps.overflowX + ps.overflowY)) {
      const pr = p.getBoundingClientRect();
      if (cx < pr.left || cx > pr.right || cy < pr.top || cy > pr.bottom) return false;
    }
  }
  const top = document.elementFromPoint(cx, cy);
  return !!top && (el.contains(top) || top.contains(el));
}

function collectVisible() {
  const STRICT = '[role="row"],[role="gridcell"],[role="cell"],tr,td,[class*="row" i],[class*="cell" i],[class*="grid" i],[class*="table" i]';
  const strict = [], loose = [];
  const seenS = new Set(), seenL = new Set();
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = w.nextNode())) {
    const t = n.nodeValue.trim();
    if (!SSCC_RE.test(t)) continue;
    const el = n.parentElement;
    if (!el || /^(SCRIPT|STYLE|INPUT|TEXTAREA)$/.test(el.tagName)) continue;
    if (!insideViewAndClips(el)) continue;
    const row = el.closest('[role="row"],tr,[class*="row" i]');
    const m = row && row.innerText.match(/\bD\d{6,}\b/);
    const rec = { sscc: t, pallet: m ? m[0] : "" };
    if (!seenL.has(t)) { seenL.add(t); loose.push(rec); }
    if (el.closest(STRICT) && !seenS.has(t)) { seenS.add(t); strict.push(rec); }
  }
  return strict.length ? { codes: strict, mode: "table" } : { codes: loose, mode: "loose" };
}

// Находит внутреннее прокручиваемое окно, в котором лежит колонка SSCC.
function findScroller() {
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = w.nextNode())) {
    if (!SSCC_RE.test(n.nodeValue.trim())) continue;
    for (let p = n.parentElement; p && p !== document.documentElement; p = p.parentElement) {
      const oy = getComputedStyle(p).overflowY;
      if (/(auto|scroll|overlay)/.test(oy) && p.scrollHeight > p.clientHeight + 2) return p;
    }
  }
  return null;
}

// Прокручивает ТОЛЬКО внутреннюю таблицу, собирает номера на каждом шаге, возвращает прокрутку на место.
async function collectAll() {
  const sc = findScroller();
  const acc = new Map();
  const grab = () => collectVisible().codes.forEach(c => { if (!acc.has(c.sscc)) acc.set(c.sscc, c); });
  if (!sc) { grab(); return { codes: [...acc.values()], scrolled: false }; }
  const orig = sc.scrollTop;
  sc.scrollTop = 0; await sleep(450);
  let stuck = 0;
  for (let i = 0; i < 120; i++) {
    grab();
    if (acc.size >= SSCC_LIMIT) break;
    const before = sc.scrollTop, maxTop = sc.scrollHeight - sc.clientHeight;
    if (before >= maxTop - 2) break;
    sc.scrollTop = Math.min(maxTop, before + Math.max(40, Math.floor(sc.clientHeight * 0.6)));
    await sleep(350);
    if (sc.scrollTop === before && ++stuck > 2) break;
  }
  await sleep(250); grab();
  sc.scrollTop = orig;
  return { codes: [...acc.values()], scrolled: true };
}

// =====================================================================
//  СТРАНИЦА ПРИЁМКИ (RDT): распознавание экрана и действия
// =====================================================================
function findButton(re) {
  const els = document.querySelectorAll('button,input[type=button],input[type=submit],a,[role=button],div,span,td,li,p');
  let best = null;
  for (const e of els) {
    const t = norm(e.tagName === "INPUT" ? e.value : e.textContent);
    if (!re.test(t) || !vis(e)) continue;
    // берём самый вложенный элемент с таким текстом
    if ([...e.children].some(c => re.test(norm(c.textContent)) && vis(c))) continue;
    best = best || e;
  }
  return best;
}

function findSsccInput() {
  const inputs = [...document.querySelectorAll("input,textarea")].filter(e =>
    vis(e) && !e.disabled && !e.readOnly && !/^(hidden|checkbox|radio|button|submit|image|file)$/i.test(e.type || ""));
  if (!inputs.length) return null;
  const labels = [...document.querySelectorAll("div,span,td,label,p,b,li")].filter(e => vis(e) && norm(e.textContent) === "SSCC");
  for (const lb of labels) {
    const nxt = inputs.find(i => !lb.contains(i) && (lb.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_FOLLOWING));
    if (nxt) return nxt;
  }
  return null; // без подписи «SSCC» поле не считаем нужным — так мы не впишем номер в чужое поле
}

function dialogText(okBtn) {
  let p = okBtn.parentElement;
  for (let i = 0; i < 5 && p; i++, p = p.parentElement) {
    const t = norm(p.innerText).replace(/(?:^|\s)(ок|ok)$/i, "").trim();
    if (t.length > 2) return t;
  }
  return "";
}

function screen() {
  const txt = norm(document.body ? document.body.innerText : "");
  const noBtn = findButton(/^нет$/i);
  if (/Регистрация груза произведена успешно/i.test(txt) && noBtn) return { kind: "success", label: "окно печати", noBtn };
  const okBtn = findButton(/^(ок|ok)$/i);
  if (okBtn) return { kind: "dialog", label: "сообщение", okBtn, message: dialogText(okBtn) };
  const input = findSsccInput(), send = findButton(/^отправить$/i);
  if (input && send && !/принтер/i.test(txt)) {
    const m = txt.match(/Принято\s*П\/Е\s*(\d+)\s*\/\s*(\d+)/i);
    return { kind: "ready", label: "ввод SSCC", input, send, counter: m ? +m[1] : null };
  }
  const h = txt.match(/Приемка ПУП\s*-\s*\d+\/\d+/i);
  return { kind: "other", label: "другой экран" + (h ? " (" + h[0] + ")" : "") };
}

function setValue(el, v) {
  const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  el.focus();
  Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

// ---------- Управление циклом ----------
const ctl = { running: false, paused: false, cmd: null, resume: null };

async function setRun(run, message) {
  await ssccMutate(s => { s.run = run; if (message !== undefined) s.message = message; });
}
async function patchItem(sscc, patch, logText) {
  await ssccMutate(s => {
    const it = s.items.find(i => i.sscc === sscc);
    if (it) Object.assign(it, patch);
    if (logText) ssccLog(s, logText);
  });
}
async function fatal(sscc, status, msg) {
  await ssccMutate(s => {
    const it = s.items.find(i => i.sscc === sscc);
    if (it) { it.status = status; it.end = Date.now(); it.msg = msg; }
    s.run = "error"; s.message = msg;
    ssccLog(s, "СТОП: " + msg);
  });
  return { fatal: true };
}

async function processOne(it) {
  const code = it.sscc;
  let sc = await waitFor(() => { const x = screen(); return x.kind === "ready" ? x : null; }, T_READY);
  if (!sc) { const x = screen(); return fatal(code, "queued", "Форма приёмки не готова к вводу. Сейчас: " + x.label + (x.message ? " — «" + x.message + "»" : "") + ". Ничего не отправлено."); }
  const before = sc.counter;
  setValue(sc.input, "");
  setValue(sc.input, code);
  if (sc.input.value !== code) return fatal(code, "queued", "Не удалось вставить номер в поле SSCC. Ничего не отправлено.");
  const send = findButton(/^отправить$/i);
  if (!send) return fatal(code, "queued", "Не найдена кнопка «Отправить». Ничего не отправлено.");

  // Помечаем «в обработке» ДО нажатия — защита от повторной отправки при сбое.
  await patchItem(code, { status: "processing", start: Date.now(), msg: "" }, "Отправка: " + code);
  send.click();

  const out = await waitFor(() => {
    const x = screen();
    if (x.kind === "success" || x.kind === "dialog") return x;
    if (x.kind === "ready" && x.input.value === "" && before != null && x.counter != null && x.counter > before) return { kind: "success-noprint" };
    return null;
  }, T_RESULT);

  if (!out) return fatal(code, "error", "Нет ответа от формы за " + T_RESULT / 1000 + " сек. Результат по " + code + " неизвестен — проверьте вручную. Следующие номера не отправлялись.");

  if (out.kind === "success" || out.kind === "success-noprint") {
    await patchItem(code, { status: "ok", end: Date.now(), msg: "" }, "Успешно: " + code);
    await ssccMutate(s => { const c = code.slice(-18); if (!s.history.includes(c)) s.history.push(c); if (s.history.length > 1000) s.history.shift(); });
    if (out.kind === "success") out.noBtn.click();
    const back = await waitFor(() => { const x = screen(); return x.kind === "ready" ? x : null; }, T_BACK);
    if (!back) { const x = screen(); return fatal(code, "ok", "Номер " + code + " принят, но форма не вернулась на ввод SSCC (сейчас: " + x.label + "). Проверьте экран."); }
    return { fatal: false };
  }

  // диалог с сообщением
  const msg = out.message || "(пустое сообщение)";
  const known = KNOWN_NOTFOUND.some(re => re.test(msg)) && !/принтер/i.test(msg);
  if (!known) return fatal(code, "error", "Неизвестная ошибка формы: «" + msg + "». Кнопки не нажимались, следующие номера не отправлялись.");
  await patchItem(code, { status: "notfound", end: Date.now(), msg: msg }, "Не найден / повторный: " + code + " — «" + msg + "»");
  out.okBtn.click();
  const back = await waitFor(() => { const x = screen(); return x.kind === "ready" ? x : null; }, T_BACK);
  if (!back) { const x = screen(); return fatal(code, "notfound", "После «Ок» форма не вернулась на ввод SSCC (сейчас: " + x.label + "). Проверьте экран."); }
  setValue(back.input, "");
  return { fatal: false };
}

async function loop(onlyOne) {
  ctl.running = true; ctl.cmd = null;
  await ssccMutate(s => { s.run = "running"; s.message = onlyOne ? "Тест одного номера" : ""; ssccLog(s, onlyOne ? "Старт: тест 1 номера" : "Старт обработки"); });
  let done = 0;
  try {
    for (;;) {
      const s = await ssccLoad();
      const next = s.items.find(i => i.status === "queued");
      if (!next) { await ssccMutate(x => { x.run = "done"; x.message = "Партия завершена. Результаты сохранены. При сборе следующей таблицы партия автоматически уйдёт в архив."; ssccLog(x, "Партия завершена"); }); break; }
      if (ctl.cmd === "stop") { await setRun("stopped", "Остановлено пользователем"); await ssccMutate(x => ssccLog(x, "Стоп")); break; }
      if (ctl.cmd === "pause") {
        await setRun("paused", "Пауза");
        await ssccMutate(x => ssccLog(x, "Пауза"));
        ctl.paused = true;
        await new Promise(r => { ctl.resume = r; });
        ctl.paused = false; ctl.resume = null;
        if (ctl.cmd === "stop") { await setRun("stopped", "Остановлено пользователем"); break; }
        ctl.cmd = null;
        await setRun("running", "");
        await ssccMutate(x => ssccLog(x, "Продолжение"));
        continue;
      }
      if (onlyOne && done >= 1) { await setRun("stopped", "Тест завершён: принят 1 номер. Проверьте результат и нажмите «НАЧАТЬ» для остальных."); break; }
      const res = await processOne(next);
      if (res.fatal) break;
      done++;
      await sleep(300);
    }
  } catch (e) {
    await ssccMutate(s => { s.run = "error"; s.message = "Внутренняя ошибка: " + e; ssccLog(s, "СТОП: внутренняя ошибка " + e); });
  } finally {
    ctl.running = false; ctl.paused = false; ctl.resume = null; ctl.cmd = null;
  }
}

// При загрузке страницы приёмки: если прошлый запуск не завершён — безопасно остановить.
async function reconcile() {
  if (!isRdt()) return;
  await ssccMutate(s => {
    let touched = false;
    for (const it of s.items) if (it.status === "processing") { it.status = "error"; it.end = Date.now(); it.msg = "Страница обновилась во время отправки — результат неизвестен, проверьте вручную"; touched = true; }
    if (s.run === "running" || s.run === "pausing" || s.run === "paused") { s.run = "stopped"; s.message = "Страница приёмки была обновлена — обработка остановлена."; touched = true; }
    if (touched) ssccLog(s, s.message);
  });
}

// ---------- Сообщения от панели ----------
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    switch (m && m.type) {
      case "PING": return { ok: true, role: isRdt() ? "rdt" : isList() ? "list" : "other", version: SSCC_VERSION };
      case "COLLECT": {
        if (!isList()) return { ok: false, error: "Это не страница списка ПУП." };
        return { ok: true, ...collectVisible() };
      }
      case "COLLECT_ALL": {
        if (!isList()) return { ok: false, error: "Это не страница списка ПУП." };
        const st = await ssccLoad();
        if (["running", "pausing", "paused"].includes(st.run)) return { ok: false, error: "Во время приёмки собирать номера нельзя." };
        const r = await collectAll();
        const add = await ssccAddCodes(r.codes, "Сбор всей таблицы");
        if (add.blocked) return { ok: false, error: "Предыдущая партия ещё не закрыта: остались номера в очереди или ошибки с неизвестным результатом. Сначала завершите старую партию либо проверьте номера и нажмите «Сбросить партию». Новые SSCC не добавлены." };
        return { ok: true, scrolled: r.scrolled, ...add };
      }
      case "PROBE": {
        if (!isRdt()) return { ok: false, error: "Это не страница приёмки." };
        const x = screen();
        return { ok: true, kind: x.kind, label: x.label, hidden: document.visibilityState !== "visible" };
      }
      case "START": case "TEST1": {
        if (!isRdt()) return { ok: false, error: "Это не страница приёмки." };
        if (ctl.running && ctl.paused) { ctl.cmd = null; ctl.resume(); return { ok: true }; }
        if (ctl.running) return { ok: false, error: "Обработка уже идёт." };
        if (document.visibilityState !== "visible") return { ok: false, error: "Вкладка приёмки скрыта или свёрнута. Выведите её на экран и повторите." };
        const s = await ssccLoad();
        if (!s.items.some(i => i.status === "queued")) return { ok: false, error: "В очереди нет номеров." };
        const x = screen();
        if (x.kind !== "ready") return { ok: false, error: "Форма приёмки не на экране ввода SSCC (сейчас: " + x.label + (x.message ? " — «" + x.message + "»" : "") + "). Приведите её к экрану ввода SSCC." };
        loop(m.type === "TEST1");
        return { ok: true };
      }
      case "PAUSE": {
        if (!ctl.running || ctl.paused) return { ok: false, error: "Сейчас не выполняется." };
        ctl.cmd = "pause";
        await setRun("pausing", "Пауза после завершения текущего номера…");
        return { ok: true };
      }
      case "STOP": {
        if (!ctl.running) { await setRun("stopped", "Остановлено пользователем"); return { ok: true }; }
        ctl.cmd = "stop";
        if (ctl.paused && ctl.resume) ctl.resume();
        else await ssccMutate(s => { s.message = "Остановка после завершения текущего номера…"; });
        return { ok: true };
      }
    }
    return { ok: false, error: "Неизвестная команда" };
  })().then(reply, e => reply({ ok: false, error: String(e) }));
  return true;
});

reconcile();
})();
