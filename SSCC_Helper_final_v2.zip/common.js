// Общие функции: состояние хранится ТОЛЬКО в chrome.storage.local (локально в браузере).
var SSCC_VERSION = "0.6.2";
var SSCC_KEY = "ssccState";
var SSCC_LIMIT = 50;

function ssccBlank() {
  return { items: [], run: "idle", message: "", history: [], log: [], batches: [] };
}
async function ssccLoad() {
  const o = await chrome.storage.local.get(SSCC_KEY);
  const s = o[SSCC_KEY] || ssccBlank();
  // Миграция старого состояния без архива партий.
  if (!Array.isArray(s.batches)) s.batches = [];
  if (!Array.isArray(s.history)) s.history = [];
  if (!Array.isArray(s.items)) s.items = [];
  if (!Array.isArray(s.log)) s.log = [];
  return s;
}
async function ssccMutate(fn) {
  const s = await ssccLoad();
  fn(s);
  await chrome.storage.local.set({ [SSCC_KEY]: s });
  return s;
}
function ssccLog(s, text) {
  s.log.push({ t: Date.now(), text: text });
  if (s.log.length > 200) s.log.splice(0, s.log.length - 200);
}

// Добавляет найденные номера. Завершённая партия архивируется автоматически
// только при поступлении первой записи следующей партии. Незавершённые партии
// никогда не смешиваются: их нужно продолжить или явно сбросить вручную.
async function ssccAddCodes(codes, label) {
  const r = { found: codes.length, added: 0, dup: 0, prev: 0, over: 0, blocked: false, archived: false };
  await ssccMutate(s => {
    const hasIncoming = codes.length > 0;
    const queued = s.items.some(i => i.status === "queued" || i.status === "processing");
    const uncertain = s.items.some(i => i.status === "error");

    if (hasIncoming && s.run === "done" && !queued && !uncertain) {
      const closedAt = Date.now();
      s.batches.push({
        id: closedAt,
        closedAt,
        result: "completed",
        total: s.items.length,
        ok: s.items.filter(i => i.status === "ok").length,
        notfound: s.items.filter(i => i.status === "notfound").length,
        errors: s.items.filter(i => i.status === "error").length,
        items: s.items.map(i => ({ ...i }))
      });
      if (s.batches.length > 100) s.batches.splice(0, s.batches.length - 100);
      s.items = [];
      s.run = "idle";
      s.message = "Предыдущая партия сохранена в архиве. Подготовлена новая партия.";
      r.archived = true;
      ssccLog(s, "Предыдущая партия автоматически закрыта и сохранена в архиве");
    } else if (hasIncoming && (queued || uncertain || ["stopped", "error", "running", "pausing", "paused"].includes(s.run))) {
      r.blocked = true;
      return;
    }

    for (const c of codes) {
      const core = c.sscc.slice(-18);
      if (s.items.some(i => i.sscc.slice(-18) === core)) { r.dup++; continue; }
      if (s.history.includes(core)) { r.prev++; continue; }
      if (s.items.length >= SSCC_LIMIT) { r.over++; continue; }
      s.items.push({ n: s.items.length + 1, sscc: c.sscc, pallet: c.pallet, status: "queued", start: 0, end: 0, msg: "" });
      r.added++;
    }
    ssccLog(s, (label || "Сбор") + ": найдено " + r.found + ", добавлено " + r.added + ", повторов " + r.dup + (r.prev ? ", принято ранее " + r.prev : "") + (r.over ? ", сверх лимита " + r.over : ""));
  });
  return r;
}
